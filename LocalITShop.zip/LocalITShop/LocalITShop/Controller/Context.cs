﻿using System.Data;
using SQLConnection;

namespace Controller
{
    public static class Context
    {
        #region Member Variables

        private static readonly SQL _sql = new SQL();

        #endregion

        #region Constructors

        #endregion

        #region Accessors

        ///This method will return all the records from the specified database table.
        public static DataTable GetDataTable(string tableName)
        {
            return _sql.GetDataTable(tableName);
        }

        /// This method will return the records based on the specified SQL query.
        public static DataTable GetDataTable(string sqlQuery, string tableName)
        {
            return _sql.GetDataTable(sqlQuery, tableName);
        }

        ///This method will return the records based on the specified SQL query.
        public static DataTable GetDataTable(string sqlQuery, string tableName, bool isReadOnly)
        {
            return _sql.GetDataTable(sqlQuery, tableName, isReadOnly);
        }

        #endregion

        #region Mutators

        public static void SaveDatabaseTable(DataTable table)
        {
            _sql.SaveDatabaseTable(table);
        }

        public static int InsertParentTable(string tableName, string columnNames, string columnValues)
        {
            return _sql.InsertParentRecord(tableName, columnNames, columnValues);
        }

        public static void DeleteRecord(string tableName, string pkName, string pkId)
        {
            _sql.DeleteRecord(tableName, pkName, pkId);
        }

        #endregion

        #region Helper Methods

        #endregion
    }
}