﻿using System.Collections.Generic;
using SQLConnection;

namespace Controller
{
    public static class Initializer
    {
        #region Member Variables

        private static readonly SQL _sql = new SQL();

        #endregion

        #region Create Database Schema

        public static void CreateDatabaseSchema()
        {
            // Call the SQL CreateDatabase method to create the database in SQL.
            _sql.CreateDatabase();
            CreateDatabaseTables();
            SeedDatabaseTables();
        }

        #endregion

        #region Create Database Tables

        private static void CreateDatabaseTables()
        {
            CreateInventoryTable();
            CreateSuppliersTable();
            CreatePurchasesTable();
            CreatePurchasesListTable();
        }

        private static void CreatePurchasesListTable()
        {
            // Create the Purchases List Table schema
            var schema = "PurchasesListID int IDENTITY(1,1) PRIMARY KEY, " +
                         "PurchasesID int NOT NULL, " +
                         "ProductID int NOT NULL, " +
                         "Quantity int NOT NULL, " +
                         "Cost DEC(7,2), " +
                         "TotalCost DEC(7,2)";

            // Call the CreateDatabaseTables method and pass the table name and schema.
            _sql.CreateDatabaseTable("PurchasesList", schema);
        }

        private static void CreatePurchasesTable()
        {
            var schema = "PurchasesID int IDENTITY(1,1) PRIMARY KEY, " +
                         "SupplierID int, " +
                         "TotalCost DEC(7,2), " +
                         "PurchaseDate DATETIME NOT NULL, " +
                         "ReceivedDate DATETIME";

            // Call the CreateDataTables method and pass the table name and schema.
            _sql.CreateDatabaseTable("Purchases", schema);
        }

        private static void CreateSuppliersTable()
        {
            // Create the Suppliers Table schema
            var schema = "SupplierID int IDENTITY(1,1) PRIMARY KEY, " +
                         "SupplierName VARCHAR(50), " +
                         "Phone VARCHAR(40), " +
                         "Email VARCHAR(80), " +
                         "ContactPerson VARCHAR(80)";

            // Call the CreateDatabaseTables method and pass the table name and schema.
            _sql.CreateDatabaseTable("Suppliers", schema);
        }

        private static void CreateInventoryTable()
        {
            // Create the Inventory Table schema
            var schema = "ProductID int IDENTITY(1,1) PRIMARY KEY, " +
                         "ProductName VARCHAR(50), " +
                         "Brand VARCHAR(30), " +
                         "Quantity int, " +
                         "Cost DEC(7,2), " +
                         "Description VARCHAR(200)";

            // Call the CreateDatabaseTables method and pass the table name and schema.
            _sql.CreateDatabaseTable("Inventory", schema);
        }

        #endregion

        #region Seed Database Tables

        private static void SeedDatabaseTables()
        {
            // Use profiling in this method and improve the performance by making sure that the method
            // calls to SeedInventory table, etc will not be called if tables in SQL already contain dummy data.
            // To help with profiling this is Microsoft link to profiling: https://docs.miscrosoft.com/en-us/visualstudio/profiling/?view=vs-2019
            // Make sure to include within technical report.

            if (_sql.GetDataTable("Inventory").Rows.Count == 0) SeedInventoryTable();

            if (_sql.GetDataTable("Suppliers").Rows.Count == 0) SeedSuppliersTable();

            if (_sql.GetDataTable("PurchasesList").Rows.Count == 0) SeedPurchasesListTable();

            if (_sql.GetDataTable("Purchases").Rows.Count == 0) SeedPurchasesTable();
        }

        private static void SeedPurchasesTable()
        {
            // Create a list of dummy data
            var purchases = new List<string>
            {
                // PurchasesID, SupplierID, TotalCost, PurchaseDate, ReceivedDate
                "1, '1', '299.99', '04/01/2020', 01/01/2020",
                "2, '1', '130.00', '07/01/2020', 01/01/2020",
                "3, '1', '122.00', '11/01/2020', 01/01/2020"
            };

            // Column names must match the order of the data above
            var columnNames = "PurchasesID, SupplierID, TotalCost, PurchaseDate, ReceivedDate";

            // Loop through the list of Inventory Items and push the data 1 Item at a time
            foreach (var PurchasesID in purchases) _sql.InsertRecord("Purchases", columnNames, PurchasesID);
        }

        private static void SeedPurchasesListTable()
        {
            // Create a list of dummy data
            var purchasesList = new List<string>
            {
                // PurchasesListID, PurchaseID, ProductID, Quantity, Cost, Total cost
                "1, 1, 1, 1, 122.00, 122.00 ",
                "2, 2, 2, 1, 130.00, 130.00 ",
                "3, 3, 3, 1, 240.00, 240.00 "
            };

            // Column names must match the order of the data above
            var columnNames = "PurchasesListID, PurchasesID, ProductID, Quantity, Cost, TotalCost";

            // Loop through the list of Inventory Items and push the data 1 Item at a time
            foreach (var PurchasesListID in purchasesList)
                _sql.InsertRecord("PurchasesList", columnNames, PurchasesListID);
        }

        private static void SeedSuppliersTable()
        {
            // Create a list of dummy data
            var suppliers = new List<string>
            {
                // SupplierID, SupplierName, Phone, Email, ContactPerson
                "1, 'The Computer Warehouse', '0011223344', 'TCW@Hotmail.com', 'Tom'",
                "1, 'The Computer Warehouse', '0011223344', 'TCW@Hotmail.com', 'Tom'",
                "1, 'The Computer Warehouse', '0011223344', 'TCW@Hotmail.com', 'Tom'"
            };

            // Column names must match the order of the data above
            var columnNames = "SupplierID, SupplierName, Phone, Email, ContactPerson";

            // Loop through the list of Inventory Items and push the data 1 Item at a time
            foreach (var SupplierID in suppliers) _sql.InsertRecord("Suppliers", columnNames, SupplierID);
        }

        private static void SeedInventoryTable()
        {
            // Create a list of dummy data
            var inventory = new List<string>
            {
                // ProductID, ProductName, Brand, Quantity, Description
                "1, '1TB External SSD Drive', 'Samsung', '500', '122.00', 'Our best SSD in stock'",
                "2, '500GB External SSD Drive', 'Toshiba', '500', '130.00', 'Our best 500GB SSD in stock'",
                "3, '500GB External SSD Drive', 'Silicon Power', '500', '240.00', 'Our most cost-effective SSD in stock'"
            };

            // Column names must match the order of the data above
            var columnNames = "ProductID, ProductName, Brand, Quantity, Cost,  Description";

            // Loop through the list of Inventory Items and push the data 1 Item at a time
            foreach (var ProductID in inventory) _sql.InsertRecord("Inventory", columnNames, ProductID);
        }

        #endregion
    }
}