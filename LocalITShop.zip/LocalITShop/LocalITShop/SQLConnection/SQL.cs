﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using NLog;

namespace SQLConnection
{
    public class SQL : IQueryDatabase, IAlterDatabase
    {
        #region Constructors

        public SQL()
        {
            // You need to include or set NLog to all our classes and forms that have the
            // try...catch so you can record the errors in your log file.
            LogManager.LoadConfiguration("NLog.config");
            _log = LogManager.GetCurrentClassLogger();

            // Get the connection string from app.config
            var connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //Initialize and create a new SqlConnection object that is needed to connect to a SQL server
            _sqlConnection = new SqlConnection(connectionString);

        }

        #endregion

        #region Member Variables

        private readonly Logger _log;
        private readonly SqlConnection _sqlConnection;
        private SqlCommand _sqlCommand;

        #endregion

        #region Query Database

        /// <summary>
        /// This method will get an updateable table from the database.
        /// </summary>
        /// <param name="tableName">Source Table</param>
        /// <returns>Data Table</returns>
        /// 

        public DataTable GetDataTable(string tableName)
        {
            var table = new DataTable(tableName);

            try
            {
                // Using a SqlDataAdapter will allow us to make a DataTable updateable as it represents a set of data commands and
                // connection that are used to update a SQL database.
                using (var adapter = new SqlDataAdapter($"SELECT * FROM {tableName}", _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    // Based on the sql query we passed as a parameter, the SqlAdapter built-in Command object will send the sql query to
                    // SQL. SQL will return with the corresponding record set and populate our DataTable named ' table '.
                    adapter.Fill(table);
                    _sqlConnection.Close();
                    // Configure DataTable and specify the PK, which is in column 0 (or the first column).
                    table.PrimaryKey = new[] { table.Columns[0] };
                    // Specify that the PK in column 0 will auto-increment.
                    table.Columns[0].AutoIncrement = true;
                    // Seed the PK value by using the last pkId value. Seeding the PK value is to simply set up the starting value of Auto-Increment.

                    // To get the current last pkId value
                    if (table.Rows.Count > 0)
                        table.Columns[0].AutoIncrementSeed = long.Parse(table.Rows[table.Rows.Count - 1][0].ToString());
                    // Set the auto-increment step by 1
                    table.Columns[0].AutoIncrementStep = 1;
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }
            return table;
        }

        /// <summary>
        /// This method will get a Read-Only table from the database.
        /// </summary>
        /// <param name="tableName">Source Table</param>
        /// <param name="isReadOnly">Specified if table is Read-Only</param>
        /// <returns>DataTable</returns>

        public DataTable GetDataTable(string tableName, bool isReadOnly)
        {
            if (isReadOnly == false) return GetDataTable(tableName);

            var table = new DataTable(tableName);

            try
            {
                using (_sqlCommand = new SqlCommand($"SELECT * FROM {tableName}", _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    using (var reader = _sqlCommand.ExecuteReader())
                    {
                        table.Load(reader);
                        _sqlConnection.Close();
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }

            return table;
        }

        /// <summary>
        /// This method will get an updateable table from the database.
        /// </summary>
        /// <param name="sqlQuery">SQL Query to retrieve records.</param>
        /// <param name="tableName"> Source Table</param>
        /// <returns>Data Table</returns>
        /// 

        public DataTable GetDataTable(string sqlQuery, string tableName)
        {
            var table = new DataTable(tableName);
            try
            {
                // Using a SqlDataAdapter will allow us to make a DataTable updateable as it represents a set of data commands and
                // connection that are used to update a SQL database.
                using (var adapter = new SqlDataAdapter(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    // Based on the sql query we passed as a parameter, the SqlAdapter built-in Command object will send the sql query to
                    // SQL. SQL will return with the corresponding record set and populate our DataTable named ' table '.
                    adapter.Fill(table);
                    _sqlConnection.Close();
                    // Configure DataTable and specify the PK, which is in column 0 (or the first column).
                    table.PrimaryKey = new[] { table.Columns[0] };
                    // Specify that the PK in column 0 will auto-increment.
                    table.Columns[0].AutoIncrement = true;
                    // Seed the PK value by using the last pkId value. Seeding the PK value is to simply set up the starting value of Auto-Increment.

                    // To get the current last pkId value
                    if (table.Rows.Count > 0)
                        table.Columns[0].AutoIncrementSeed = long.Parse(table.Rows[table.Rows.Count - 1][0].ToString());
                    // Set the auto-increment step by 1
                    table.Columns[0].AutoIncrementStep = 1;
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }

            return table;
        }

        /// <summary>
        /// This method will get a Read-Only table from the database.
        /// </summary>
        /// <param name="sqlQuery">SQL Query to retrieve records.</param>
        /// <param name="tableName">Source Table</param>
        /// <param name="isReadOnly">Specify if table is Read-Only</param>
        /// <returns>DataTable</returns>
        /// 

        public DataTable GetDataTable(string sqlQuery, string tableName, bool isReadOnly)
        {
            if (isReadOnly == false) return GetDataTable(sqlQuery, tableName);

            var table = new DataTable(tableName);

            try
            {
                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    using (var reader = _sqlCommand.ExecuteReader())
                    {
                        table.Load(reader);
                        _sqlConnection.Close();
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }

            return table;
        }

        #endregion

        #region Alter Database

        /// <summary>
        /// This method will alter the specified database table on a specified server and database
        /// </summary>
        /// <param name="tableName">Table Name</param>
        /// <param name="tableStructure">Table Structure</param>
        
        public void AlterDatabaseTable(string tableName, string tableStructure)
        {
            try
            {
                var sqlQuery = $"ALTER TABLE {tableName} ({tableStructure})";

                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    _sqlCommand.ExecuteNonQuery();
                    _sqlConnection.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }
        }

        /// <summary>
        /// This method will create the database on SQL server.
        /// </summary>

        public void CreateDatabase()
        {

            // Create another SqlConnection to point to the server without the database name
            var serverConnString = $"Data Source={_sqlConnection.DataSource};" +
                                   "Integrated Security = True";
            var sqlServerConn = new SqlConnection(serverConnString);

            // Create a SQL script to create the database. Check the SQL syntax of
            // creating a database in w3schools.
            var sqlScript = "IF NOT EXISTS ( SELECT 1 FROM sys.databases " +
                            $"WHERE name = '{_sqlConnection.Database}')" +
                            $"CREATE DATABASE {_sqlConnection.Database}";

            // Create the SqlCommand object that will execute the SQL script above
            _sqlCommand = new SqlCommand(sqlScript, sqlServerConn);

            // Check if SqlConnection object is closed before opening, otherwise an error will occur.
            if (sqlServerConn.State == ConnectionState.Closed)
            {
                // Open the SqlConnection object so the SqlCommand object can
                // execute the query.
                sqlServerConn.Open();

                // Run the SQL script using the SqlCommand object
                _sqlCommand.ExecuteNonQuery();
                // Close the SqlConnection object as soon as we are done with it.
                sqlServerConn.Close();

            }
        }

        public int TableRowCount(string tableName)
        {
            var rowCount = 1;
            try
            {
                var sqlQuery = $"SELECT COUNT(*) FROM {tableName}";
                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    rowCount = (int)_sqlCommand.ExecuteScalar();
                    _sqlConnection.Close();
                }
            }
            catch (Exception e)
            {
                _log.Error(e.ToString());
            }
            return rowCount;

        }

        /// <summary>
        /// This method will reate a database table on a specified server and database
        /// </summary>
        /// <param name="tableName">The table name to be created</param>
        /// <param name="tableStructure">The table schema to be added in the table </param>

        public void CreateDatabaseTable(string tableName, string tableStructure)
        {
            try
            {

                //TODO: Check if table exists in profiling
                // Create the table in the database.
                var sqlQuery = "IF NOT EXISTS (SELECT name FROM sysobjects " +
                               $"WHERE name = '{tableName}') " +
                               $"CREATE TABLE {tableName} ({tableStructure})";

                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed)
                        _sqlConnection.Open();
                    _sqlCommand.ExecuteNonQuery();
                    _sqlConnection.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }
            finally
            {
                _sqlConnection.Close();
            }
        }

        /// <summary>
        /// This method will delete a record in the database.
        /// </summary>
        /// <param name="tableName">Table Name</param>
        /// <param name="pkName">PK Name</param>
        /// <param name="pkId">PK ID</param>

        public void DeleteRecord(string tableName, string pkName, string pkId)
        {
            var sqlQuery = $"DELETE FROM {tableName} WHERE {pkName} = {pkId} SELECT SCOPE_IDENTITY()";

            try
            {
                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    _sqlCommand.ExecuteScalar();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }
        }

        /// <summary>
        /// This method will insert a record in the database.
        /// </summary>
        /// <param name="tableName">Destination  Table</param>
        /// <param name="columnNames">Column Names of the Table</param>
        /// <param name="columnValues">Column Values</param>
        /// <returns>int NewID</returns>

        public int InsertParentRecord(string tableName, string columnNames, string columnValues)
        {
            var Id = 0;

            try
            {
                var sqlQuery = $"INSERT INTO {tableName} ({columnNames}) " +
                               $"VALUES ({columnValues}) " +
                               "SELECT SCOPE_IDENTITY()";

                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    Id = (int)(decimal)_sqlCommand.ExecuteScalar();
                    _sqlConnection.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }

            return Id;
        }

        /// <summary>
        /// This method will insert a record in the table.
        /// </summary>
        /// <param name="tableName">Table name where record will be inserted.</param>
        /// <param name="columnNames">Column names of the table.</param>
        /// <param name="columnValues">Column values to be inserted.</param>
        /// <returns>An int representing the primary key value of the newly inserted record.
        /// </returns>

        public int InsertRecord(string tableName, string columnNames, string columnValues)
        {
            var id = 0;

            var sqlQuery = $"SET IDENTITY_INSERT {tableName} ON " +
                           $"INSERT INTO {tableName} ({columnNames}) " +
                           $"VALUES ({columnValues}) " +
                           $"SET IDENTITY_INSERT {tableName} OFF " +
                           "SELECT SCOPE_IDENTITY()";
            try
            {
                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed)
                        _sqlConnection.Open();

                    id = (int)(decimal)_sqlCommand.ExecuteScalar();
                    _sqlConnection.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                _log.Error(e.ToString());
            }
            finally
            {
                _sqlConnection.Close();
            }
            return id;
        }

        /// <summary>
        /// This method will update a database table.
        /// </summary>
        /// <param name="dataTable">Source Table to be updated.</param>

        public void SaveDatabaseTable(DataTable dataTable)
        {
            try
            {
                using (var adapter = new SqlDataAdapter($"SELECT * FROM {dataTable.TableName}", _sqlConnection))
                {
                    // Using the SqlCommandBuilder to create the Insert, Update, and Delete command
                    // automatically based on the query we have specified. Above when initializing
                    // a SqlDataAdapter.
                    var commandBulder = new SqlCommandBuilder(adapter);
                    adapter.InsertCommand = commandBulder.GetInsertCommand();
                    adapter.UpdateCommand = commandBulder.GetUpdateCommand();
                    adapter.DeleteCommand = commandBulder.GetDeleteCommand();

                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    adapter.Update(dataTable);
                    _sqlConnection.Close();
                    dataTable.AcceptChanges();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                _log.Error(e.ToString());
            }
        }

        /// <summary>
        /// This method will update a record in the database.
        /// </summary>
        /// <param name="tableName">Table Name</param>
        /// <param name="columnNamesAndValues">Column Names and Corresponding Values</param>
        /// <param name="criteria">Update Criteria</param>
        /// <returns>bool isOk</returns>
      
        public bool UpdateRecord(string tableName, string columnNamesAndValues, string criteria)
        {
            // We forgot to implement this.
            var isOk = false;

            var sqlQuery = $"UPDATE {tableName} SET {columnNamesAndValues} WHERE {criteria}";

            try
            {
                using (_sqlCommand = new SqlCommand(sqlQuery, _sqlConnection))
                {
                    if (_sqlConnection.State == ConnectionState.Closed) _sqlConnection.Open();
                    _sqlCommand.ExecuteNonQuery();
                    isOk = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                isOk = false;
                _log.Error(e.ToString());
            }

            return isOk;
        }

        #endregion
    }
}
