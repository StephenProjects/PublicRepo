﻿using System;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmPurchasesList : Form
    {
        #region Member Variables

        #endregion

        #region Constructors

        public frmPurchasesList()
        {
            InitializeComponent();
        }

        #endregion

        #region Form Events

        private void frmPurchasesList_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        private void frmPurchasesList_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion

        #region Button Events

        private void lnkAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var frm = new frmPurchases();
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvPurchasesList_DoubleClick(object sender, EventArgs e)
        {
            if (dgvPurchasesList.CurrentCell == null) return;

            var PKID = long.Parse(dgvPurchasesList[0, dgvPurchasesList.CurrentCell.RowIndex].Value.ToString());

            var frm = new frmPurchases(PKID);
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var PKID = dgvPurchasesList[0, dgvPurchasesList.CurrentCell.RowIndex].Value.ToString();

            Context.DeleteRecord("Purchases", "PurchasesID", PKID);
            PopulateGrid();
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// The populate grid method is used to import information from the database to our data grid view, we are using a SQL query to simplify the coding.
        /// </summary>
        private void PopulateGrid()
        {
            var sqlQuery =
                "SELECT Purchases.PurchasesID, Suppliers.SupplierName, Purchases.PurchaseDate, Purchases.ReceivedDate " +
                "FROM Purchases INNER JOIN " +
                "Suppliers ON Purchases.SupplierID = Suppliers.SupplierID " +
                "ORDER BY Purchases.PurchasesID DESC";

            var table = Context.GetDataTable(sqlQuery, "Purchases");
            dgvPurchasesList.DataSource = table;
        }

        #endregion
        
    }
}