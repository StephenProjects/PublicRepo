﻿using System;
using System.Data;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmInventory : Form
    {
        #region Form Events

        private void frmInventory_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        #endregion

        #region Member Variables

        private readonly long _pkId;
        private DataTable _inventoryTable;
        private readonly bool _isNew;

        #endregion

        #region Constructors

        // Constructor for creating new record

        public frmInventory()
        {
            InitializeComponent();
            _isNew = true;
            SetupForm();
        }

        // Constructor for updating an existing record
        public frmInventory(long pkId)
        {
            InitializeComponent();
            _pkId = pkId;
            SetupForm();
        }

        private void SetupForm()
        {
            InitializeDataTable();
            BindControls();
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // IMPORTANT: Always do the EndEdit, otherwise the data will not persist
            _inventoryTable.Rows[0].EndEdit();
            // Call the Save method of the Context class to save the changes to the database.
            Context.SaveDatabaseTable(_inventoryTable);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        ///     This methid will initialize the DataTable that we will use in binding this form. The data of the table will come
        ///     from SQL server.
        /// </summary>
        private void InitializeDataTable()
        {
            var sqlQuery = $"SELECT * FROM Inventory WHERE ProductID = {_pkId}";

            // Get an existing inventory record based on the _pkId and the data table will be updateable.
            _inventoryTable = Context.GetDataTable(sqlQuery, "Inventory");

            // Check if it is a new record.
            if (_isNew)
            {
                var row = _inventoryTable.NewRow();
                _inventoryTable.Rows.Add(row);
            }
        }

        private void BindControls()
        {
            // Binding the Textbox with the _inventoryTable and mapping it to the database field
            // called 'ProductID' and using the 'Text' property of the Textbox to display the value of the field.
            txtProductID.DataBindings.Add("Text", _inventoryTable, "ProductID");
            txtProductName.DataBindings.Add("Text", _inventoryTable, "ProductName");
            txtBrand.DataBindings.Add("Text", _inventoryTable, "Brand");
            txtCost.DataBindings.Add("Text", _inventoryTable, "Cost");
            txtQuantity.DataBindings.Add("Text", _inventoryTable, "Quantity");
            txtDescription.DataBindings.Add("Text", _inventoryTable, "Description");
        }

        #endregion
    }
}