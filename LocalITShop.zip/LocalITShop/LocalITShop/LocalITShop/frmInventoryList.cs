﻿using System;
using System.Data;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmInventoryList : Form
    {
        #region Constructors

        public frmInventoryList()
        {
            InitializeComponent();
        }

        #endregion

        #region Member Variables

        #endregion

        #region Helper Methods

        /// <summary>
        ///     Populate grid is a method used to focus data and update or populate the grid whenever necessary.
        /// </summary>
        private void PopulateGrid()
        {
            var dtb = new DataTable();
            dtb = Context.GetDataTable("Inventory");
            dgvInventoryList.DataSource = dtb;
        }

        private void dgvInventoryList_DoubleClick(object sender, EventArgs e)
        {
            // If no current row or cell seleced, do nothing
            if (dgvInventoryList.CurrentCell == null) return;

            // Get the primary key ID of the selected row, which is in column 0
            var pkId = long.Parse(dgvInventoryList[0, dgvInventoryList.CurrentCell.RowIndex].Value.ToString());

            var frm = new frmInventory(pkId);
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lnkAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var frm = new frmInventory();
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        private void dgvInventoryList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var PKID = dgvInventoryList[0, dgvInventoryList.CurrentCell.RowIndex].Value.ToString();

            Context.DeleteRecord("Inventory", "ProductID", PKID);
            PopulateGrid();
        }

        #endregion

        #region Form Events

        private void frmInventoryList_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        private void frmInventoryList_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion
    }
}