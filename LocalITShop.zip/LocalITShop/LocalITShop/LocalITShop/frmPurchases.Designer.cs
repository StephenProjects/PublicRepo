﻿namespace LocalITShop
{
    partial class frmPurchases
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReceivedDate = new System.Windows.Forms.Label();
            this.lblPurchaseOrderTotal = new System.Windows.Forms.Label();
            this.txtPurchaseOrderTotal = new System.Windows.Forms.TextBox();
            this.lblPurchaseDate = new System.Windows.Forms.Label();
            this.lblSupplierName = new System.Windows.Forms.Label();
            this.lblPurchaseID = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblPurchases = new System.Windows.Forms.Label();
            this.dtpPurchaseDate = new System.Windows.Forms.DateTimePicker();
            this.dtpReceivedDate = new System.Windows.Forms.DateTimePicker();
            this.gbxItems = new System.Windows.Forms.GroupBox();
            this.dgvPurchasedItems = new System.Windows.Forms.DataGridView();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnInsertItem = new System.Windows.Forms.Button();
            this.btnCreatePurchase = new System.Windows.Forms.Button();
            this.cboSupplierName = new System.Windows.Forms.ComboBox();
            this.txtPurchaseID = new System.Windows.Forms.TextBox();
            this.gbxItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchasedItems)).BeginInit();
            this.SuspendLayout();
            // 
            // lblReceivedDate
            // 
            this.lblReceivedDate.AutoSize = true;
            this.lblReceivedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceivedDate.Location = new System.Drawing.Point(12, 218);
            this.lblReceivedDate.Name = "lblReceivedDate";
            this.lblReceivedDate.Size = new System.Drawing.Size(132, 20);
            this.lblReceivedDate.TabIndex = 34;
            this.lblReceivedDate.Text = "Received Date:";
            // 
            // lblPurchaseOrderTotal
            // 
            this.lblPurchaseOrderTotal.AutoSize = true;
            this.lblPurchaseOrderTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseOrderTotal.Location = new System.Drawing.Point(12, 140);
            this.lblPurchaseOrderTotal.Name = "lblPurchaseOrderTotal";
            this.lblPurchaseOrderTotal.Size = new System.Drawing.Size(184, 20);
            this.lblPurchaseOrderTotal.TabIndex = 32;
            this.lblPurchaseOrderTotal.Text = "Purchase Order Total:";
            // 
            // txtPurchaseOrderTotal
            // 
            this.txtPurchaseOrderTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchaseOrderTotal.Location = new System.Drawing.Point(273, 134);
            this.txtPurchaseOrderTotal.Name = "txtPurchaseOrderTotal";
            this.txtPurchaseOrderTotal.Size = new System.Drawing.Size(396, 26);
            this.txtPurchaseOrderTotal.TabIndex = 31;
            // 
            // lblPurchaseDate
            // 
            this.lblPurchaseDate.AutoSize = true;
            this.lblPurchaseDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseDate.Location = new System.Drawing.Point(12, 180);
            this.lblPurchaseDate.Name = "lblPurchaseDate";
            this.lblPurchaseDate.Size = new System.Drawing.Size(133, 20);
            this.lblPurchaseDate.TabIndex = 30;
            this.lblPurchaseDate.Text = "Purchase Date:";
            // 
            // lblSupplierName
            // 
            this.lblSupplierName.AutoSize = true;
            this.lblSupplierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplierName.Location = new System.Drawing.Point(12, 100);
            this.lblSupplierName.Name = "lblSupplierName";
            this.lblSupplierName.Size = new System.Drawing.Size(131, 20);
            this.lblSupplierName.TabIndex = 27;
            this.lblSupplierName.Text = "Supplier Name:";
            // 
            // lblPurchaseID
            // 
            this.lblPurchaseID.AutoSize = true;
            this.lblPurchaseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseID.Location = new System.Drawing.Point(12, 61);
            this.lblPurchaseID.Name = "lblPurchaseID";
            this.lblPurchaseID.Size = new System.Drawing.Size(113, 20);
            this.lblPurchaseID.TabIndex = 26;
            this.lblPurchaseID.Text = "Purchase ID:";
            // 
            // btnSave
            // 
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(438, 502);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(114, 45);
            this.btnSave.TabIndex = 25;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(558, 502);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 45);
            this.btnClose.TabIndex = 24;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblPurchases
            // 
            this.lblPurchases.AutoSize = true;
            this.lblPurchases.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchases.Location = new System.Drawing.Point(15, 9);
            this.lblPurchases.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPurchases.Name = "lblPurchases";
            this.lblPurchases.Size = new System.Drawing.Size(123, 25);
            this.lblPurchases.TabIndex = 23;
            this.lblPurchases.Text = "Purchases";
            // 
            // dtpPurchaseDate
            // 
            this.dtpPurchaseDate.CustomFormat = "dd-MMM-yyyy";
            this.dtpPurchaseDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPurchaseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPurchaseDate.Location = new System.Drawing.Point(273, 171);
            this.dtpPurchaseDate.Name = "dtpPurchaseDate";
            this.dtpPurchaseDate.Size = new System.Drawing.Size(279, 26);
            this.dtpPurchaseDate.TabIndex = 35;
            // 
            // dtpReceivedDate
            // 
            this.dtpReceivedDate.CustomFormat = "dd-MMM-yyyy";
            this.dtpReceivedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReceivedDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReceivedDate.Location = new System.Drawing.Point(273, 209);
            this.dtpReceivedDate.Name = "dtpReceivedDate";
            this.dtpReceivedDate.Size = new System.Drawing.Size(279, 26);
            this.dtpReceivedDate.TabIndex = 36;
            // 
            // gbxItems
            // 
            this.gbxItems.Controls.Add(this.dgvPurchasedItems);
            this.gbxItems.Controls.Add(this.btnDeleteItem);
            this.gbxItems.Controls.Add(this.btnInsertItem);
            this.gbxItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxItems.Location = new System.Drawing.Point(17, 259);
            this.gbxItems.Name = "gbxItems";
            this.gbxItems.Size = new System.Drawing.Size(655, 237);
            this.gbxItems.TabIndex = 37;
            this.gbxItems.TabStop = false;
            this.gbxItems.Text = "Purchased Items";
            // 
            // dgvPurchasedItems
            // 
            this.dgvPurchasedItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPurchasedItems.Location = new System.Drawing.Point(7, 26);
            this.dgvPurchasedItems.Name = "dgvPurchasedItems";
            this.dgvPurchasedItems.Size = new System.Drawing.Size(642, 167);
            this.dgvPurchasedItems.TabIndex = 40;
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(340, 199);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(299, 32);
            this.btnDeleteItem.TabIndex = 39;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            // 
            // btnInsertItem
            // 
            this.btnInsertItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertItem.Location = new System.Drawing.Point(6, 199);
            this.btnInsertItem.Name = "btnInsertItem";
            this.btnInsertItem.Size = new System.Drawing.Size(306, 32);
            this.btnInsertItem.TabIndex = 38;
            this.btnInsertItem.Text = "Insert Item";
            this.btnInsertItem.UseVisualStyleBackColor = true;
            this.btnInsertItem.Click += new System.EventHandler(this.btnInsertItem_Click);
            // 
            // btnCreatePurchase
            // 
            this.btnCreatePurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreatePurchase.Location = new System.Drawing.Point(571, 171);
            this.btnCreatePurchase.Name = "btnCreatePurchase";
            this.btnCreatePurchase.Size = new System.Drawing.Size(98, 67);
            this.btnCreatePurchase.TabIndex = 40;
            this.btnCreatePurchase.Text = "Create Purchase";
            this.btnCreatePurchase.UseVisualStyleBackColor = true;
            this.btnCreatePurchase.Click += new System.EventHandler(this.btnCreatePurchase_Click);
            // 
            // cboSupplierName
            // 
            this.cboSupplierName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSupplierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSupplierName.FormattingEnabled = true;
            this.cboSupplierName.Location = new System.Drawing.Point(273, 96);
            this.cboSupplierName.Name = "cboSupplierName";
            this.cboSupplierName.Size = new System.Drawing.Size(396, 24);
            this.cboSupplierName.TabIndex = 41;
            this.cboSupplierName.SelectedIndexChanged += new System.EventHandler(this.cboSupplierName_SelectedIndexChanged);
            // 
            // txtPurchaseID
            // 
            this.txtPurchaseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchaseID.Location = new System.Drawing.Point(273, 60);
            this.txtPurchaseID.Name = "txtPurchaseID";
            this.txtPurchaseID.Size = new System.Drawing.Size(396, 26);
            this.txtPurchaseID.TabIndex = 42;
            // 
            // frmPurchases
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 559);
            this.Controls.Add(this.txtPurchaseID);
            this.Controls.Add(this.cboSupplierName);
            this.Controls.Add(this.btnCreatePurchase);
            this.Controls.Add(this.gbxItems);
            this.Controls.Add(this.dtpReceivedDate);
            this.Controls.Add(this.dtpPurchaseDate);
            this.Controls.Add(this.lblReceivedDate);
            this.Controls.Add(this.lblPurchaseOrderTotal);
            this.Controls.Add(this.txtPurchaseOrderTotal);
            this.Controls.Add(this.lblPurchaseDate);
            this.Controls.Add(this.lblSupplierName);
            this.Controls.Add(this.lblPurchaseID);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblPurchases);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPurchases";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchases";
            this.Load += new System.EventHandler(this.frmPurchases_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmPurchases_Paint);
            this.gbxItems.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchasedItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblReceivedDate;
        private System.Windows.Forms.Label lblPurchaseOrderTotal;
        private System.Windows.Forms.TextBox txtPurchaseOrderTotal;
        private System.Windows.Forms.Label lblPurchaseDate;
        private System.Windows.Forms.Label lblSupplierName;
        private System.Windows.Forms.Label lblPurchaseID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblPurchases;
        private System.Windows.Forms.DateTimePicker dtpPurchaseDate;
        private System.Windows.Forms.DateTimePicker dtpReceivedDate;
        private System.Windows.Forms.GroupBox gbxItems;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.Button btnInsertItem;
        private System.Windows.Forms.Button btnCreatePurchase;
        private System.Windows.Forms.ComboBox cboSupplierName;
        private System.Windows.Forms.TextBox txtPurchaseID;
        private System.Windows.Forms.DataGridView dgvPurchasedItems;
    }
}