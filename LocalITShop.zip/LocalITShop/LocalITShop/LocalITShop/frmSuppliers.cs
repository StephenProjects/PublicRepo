﻿using System;
using System.Data;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmSuppliers : Form
    {
        #region Form Events

        private void frmSuppliers_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        #endregion

        #region Member Variables

        private readonly long _pkId;
        private DataTable _suppliersTable;
        private readonly bool _isNew;

        #endregion

        #region Constructors

        // Constructors for creating a new record.
        public frmSuppliers()
        {
            InitializeComponent();
            _isNew = true;
            SetupForm();
        }

        public frmSuppliers(long pkId)
        {
            InitializeComponent();
            _pkId = pkId;
            SetupForm();
        }

        private void SetupForm()
        {
            InitializeDataTable();
            BindControls();
        }

        #endregion

        #region Helper Methods

        /// <summary>
        ///     This methid will initialize the DataTable that we will use in binding this form. The data of the table will come
        ///     from SQL server.
        /// </summary>
        private void InitializeDataTable()
        {
            var sqlQuery = $"SELECT * FROM Suppliers WHERE SupplierID = {_pkId}";

            // Get an existing inventory record based on the _pkId and the data table will be updateable.
            _suppliersTable = Context.GetDataTable(sqlQuery, "Suppliers");

            // Check if it is a new record.
            if (_isNew)
            {
                var row = _suppliersTable.NewRow();
                _suppliersTable.Rows.Add(row);
            }
        }

        private void BindControls()
        {
            // Binding the Textbox with the _inventoryTable and mapping it to the database field
            // called 'ProductID' and using the 'Text' property of the Textbox to display the value of the field.
            txtSupplierID.DataBindings.Add("Text", _suppliersTable, "SupplierID");
            txtSupplierName.DataBindings.Add("Text", _suppliersTable, "SupplierName");
            txtPhone.DataBindings.Add("Text", _suppliersTable, "Phone");
            txtEmail.DataBindings.Add("Text", _suppliersTable, "Email");
            txtContactPerson.DataBindings.Add("Text", _suppliersTable, "ContactPerson");
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            // IMPORTANT: Always do the EndEdit, otherwise the data will not persist
            _suppliersTable.Rows[0].EndEdit();
            // Call the Save method of the Context class to save the changes to the database.
            Context.SaveDatabaseTable(_suppliersTable);
            Refresh();
        }

        #endregion
    }
}