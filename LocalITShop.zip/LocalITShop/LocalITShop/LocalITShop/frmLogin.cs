﻿using System;
using System.IO;
using System.Windows.Forms;

namespace LocalITShop
{
    public partial class frmLogin : Form
    {
        #region Constructors

        public frmLogin()
        {
            InitializeComponent();
        }

        #endregion

        #region Helper Method

        private bool CheckDetails(int i, string[] fileDetails, string userName, string passWord)
        {
            //splits line into parts
            var lineParts = fileDetails[i].Split('|');
            //left part of combo
            var fileUserName = lineParts[0];
            //right part of combo
            var filePassword = lineParts[1];

            if (userName.Equals(fileUserName))

                if (passWord.Equals(filePassword))
                    return true;
            return false;
        }

        #endregion

        #region Member Variables

        private string userName = "admin";
        private string passWord = "password";

        #endregion

        #region Click Event

        private void lblUsername_Click(object sender, EventArgs e)
        {
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var fileData = File.ReadAllLines("users.txt");

            var accountFound = false;
            var i = 0;

            while (!accountFound && i < fileData.Length)
            {
                if (fileData[i].Contains("|"))

                {
                    accountFound = CheckDetails(i, fileData, txtUsername.Text, txtPassword.Text);
                    if (accountFound)
                    {
                        MessageBox.Show("Username and Password Correct!");
                        var menuForm = new frmMenu();
                        menuForm.DialogResult = menuForm.ShowDialog();
                        if (menuForm.DialogResult == DialogResult.OK) MessageBox.Show("IT WORKED!");

                        Hide();
                    }
                }

                i++;
            }

            if (!accountFound) MessageBox.Show("Username or Password Incorrect!");
        }

        #endregion
    }
}