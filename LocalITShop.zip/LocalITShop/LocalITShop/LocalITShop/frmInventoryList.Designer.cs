﻿namespace LocalITShop
{
    partial class frmInventoryList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lnkAdd = new System.Windows.Forms.LinkLabel();
            this.lblInventoryList = new System.Windows.Forms.Label();
            this.dgvInventoryList = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryList)).BeginInit();
            this.SuspendLayout();
            // 
            // lnkAdd
            // 
            this.lnkAdd.AutoSize = true;
            this.lnkAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAdd.Location = new System.Drawing.Point(13, 60);
            this.lnkAdd.Name = "lnkAdd";
            this.lnkAdd.Size = new System.Drawing.Size(147, 20);
            this.lnkAdd.TabIndex = 0;
            this.lnkAdd.TabStop = true;
            this.lnkAdd.Text = "Add New Product";
            this.lnkAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAdd_LinkClicked);
            // 
            // lblInventoryList
            // 
            this.lblInventoryList.AutoSize = true;
            this.lblInventoryList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInventoryList.Location = new System.Drawing.Point(12, 9);
            this.lblInventoryList.Name = "lblInventoryList";
            this.lblInventoryList.Size = new System.Drawing.Size(154, 25);
            this.lblInventoryList.TabIndex = 1;
            this.lblInventoryList.Text = "Inventory List";
            // 
            // dgvInventoryList
            // 
            this.dgvInventoryList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventoryList.Location = new System.Drawing.Point(12, 88);
            this.dgvInventoryList.Name = "dgvInventoryList";
            this.dgvInventoryList.Size = new System.Drawing.Size(377, 323);
            this.dgvInventoryList.TabIndex = 2;
            this.dgvInventoryList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInventoryList_CellContentClick);
            this.dgvInventoryList.DoubleClick += new System.EventHandler(this.dgvInventoryList_DoubleClick);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(275, 423);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 45);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItem.Location = new System.Drawing.Point(155, 423);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(114, 45);
            this.btnDeleteItem.TabIndex = 4;
            this.btnDeleteItem.Text = "Delete";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            this.btnDeleteItem.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmInventoryList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 480);
            this.Controls.Add(this.btnDeleteItem);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dgvInventoryList);
            this.Controls.Add(this.lblInventoryList);
            this.Controls.Add(this.lnkAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmInventoryList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory List";
            this.Load += new System.EventHandler(this.frmInventoryList_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmInventoryList_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventoryList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lnkAdd;
        private System.Windows.Forms.Label lblInventoryList;
        private System.Windows.Forms.DataGridView dgvInventoryList;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDeleteItem;
    }
}