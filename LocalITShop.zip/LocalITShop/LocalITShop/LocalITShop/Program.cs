﻿using System;
using System.Windows.Forms;
using Controller;

namespace LocalITShop
{
    internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            // Calls the Initializer to create the database schema and populate
            // the tables with dummy data.
            Initializer.CreateDatabaseSchema();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmLogin());
        }
    }
}