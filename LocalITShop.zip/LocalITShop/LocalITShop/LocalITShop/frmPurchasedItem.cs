﻿using System;
using System.Data;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmPurchasedItem : Form
    {
        #region Form Events

        private void frmPurchasedItem_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        //private void Total()
        //{
        //    var Main1 = Convert.ToInt32(txtQuantity.Text);
        //    var Main2 = Convert.ToInt32(txtCost.Text);
        //    var Main3 = Main1 * Main2;
        //    txtTotalCost.Text = Main3.ToString();
        //}

        #endregion

        #region Member Variables

        private readonly long _PKID;
        private readonly long _PurchasesID;
        private DataTable _dtbPurchasesList;
        private DataTable _dtbInventory;
        private readonly bool _isNew;

        #endregion

        #region Constructors

        /// <summary>
        ///     This constructor is to create a NEW Product and it required the PurchaseID (FK)
        ///     so that this NEW Product will know its parent record in the Purchases table.
        ///     Since we already have a contructor that accepts a parameter of type long, in this
        ///     constructor we will accept a parameter of type string.
        /// </summary>
        public frmPurchasedItem(string PurchasesId)
        {
            _isNew = true;
            _PurchasesID = long.Parse(PurchasesId);
            InitializeComponent();
            InitializeDataTable();
            txtQuantity.Text = "0";
        }

        /// <summary>
        ///     This constructor will open an existing Product based on the pkID parameter.
        /// </summary>
        public frmPurchasedItem(long pkID)
        {
            InitializeComponent();
            _PKID = pkID;
            InitializeDataTable();
            txtQuantity.Text = "0";
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// This method is used to create an initial data table.
        /// </summary>
        private void InitializeDataTable()
        {
            var sql = $"SELECT * FROM PurchasesList WHERE PurchasesListID = {_PKID}";
            _dtbPurchasesList = Context.GetDataTable(sql, "PurchasesList");

            if (_isNew)
            {
                var row = _dtbPurchasesList.NewRow();
                _dtbPurchasesList.Rows.Add(row);
            }
        }

        /// <summary>
        /// Once the data table is created we are able to import selected fields and their respective data from within the database.
        /// </summary>
        private void BindControls()
        {
            txtPurchaseOrder.DataBindings.Add("Text", _dtbPurchasesList, "PurchasesID");
            cboPurchasedItem.DataBindings.Add("SelectedValue", _dtbPurchasesList, "ProductID");
            txtQuantity.DataBindings.Add("Text", _dtbPurchasesList, "Quantity");
            txtCost.DataBindings.Add("Text", _dtbPurchasesList, "Cost");
            txtTotalCost.DataBindings.Add("Text", _dtbPurchasesList, "TotalCost");
        }

        /// <summary>
        /// We will use this method to put valued into the combobox in the purchased item table. The data input into the combobox will be seeded from the _dtbInventory table.
        /// </summary>
        private void PopulateComboBox()
        {
            _dtbInventory = new DataTable();
            _dtbInventory = Context.GetDataTable("Inventory");
            cboPurchasedItem.ValueMember = "ProductID";
            cboPurchasedItem.DisplayMember = "ProductName";
            cboPurchasedItem.DataSource = _dtbInventory;
        }

        #endregion

        #region Button Events

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_isNew)
            {
                // This block of ode is a hack to make sure that the Validate event of the
                // TextBox txtPurchaseID will trigger and subsequently will store the value
                // of txtPurchaseID in the database _dtbPurchasedItems
                txtPurchaseOrder.Focus();
                txtPurchaseOrder.Text = _PurchasesID.ToString();
                txtCost.Text = _dtbInventory.Rows[0].ToString();
                txtCost.Focus();
                txtQuantity.Focus();
                txtTotalCost.Text = (decimal.Parse(txtCost.Text) * decimal.Parse(txtQuantity.Text)).ToString();
                btnSave.Focus();
            }

            _dtbPurchasesList.Rows[0].EndEdit();
            Context.SaveDatabaseTable(_dtbPurchasesList);
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmPurchasedItem_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
            BindControls();
            if (_isNew)
                txtPurchaseOrder.Text = _PurchasesID.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtTotalCost_TextChanged(object sender, EventArgs e)
        {
            //Total();
        }

        #endregion
    }
}