﻿using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmReportOne : Form
    {
        #region Member Variables

        private DataView _dvHistory; // Data Source of our grid. Easy to filter than DataTable.

        #endregion

        #region Constructors

        public frmReportOne()
        {
            InitializeComponent();
        }

        #endregion

        #region Form Events

        private void frmReportOne_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        private void frmReportOne_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // The "%" is a wildcard. This means that whatever text we enter in txtSearch, we will search of SupplierName or ProductName contains the text entered.
            _dvHistory.RowFilter = $"SupplierName LIKE '%{txtSearch.Text}%'";
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            // Use StringBuilder to build CSV files
            var csv = new StringBuilder();

            // Loop through each row of the DataView History and we append each row to our csv string.
            foreach (DataRowView drv in _dvHistory)
                csv.AppendLine($"{drv["PurchasesID"]}, " +
                               $"{drv["SupplierName"]}, " +
                               $"{drv["TotalCost"]}, " +
                               $"{drv["PurchaseDate"]}, " +
                               $"{drv["ReceivedDate"]}");


            // Writes the csv string in the Debug folder or where the .exe is located.
            // The name of the csv file is 'InventoryHistory'.
            File.WriteAllText(Application.StartupPath + @"\InventoryHistory.csv", csv.ToString());
            MessageBox.Show("Export Completed.", Settings.Default.ProjectName);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// The populate grid method is used to import information from the database to our data grid view, we are using a SQL query to simplify the coding.
        /// </summary>
        private void PopulateGrid()
        {
            var sqlQuery =
                "SELECT Purchases.PurchasesID, Suppliers.SupplierName, Purchases.TotalCost, Purchases.PurchaseDate, Purchases.ReceivedDate " +
                "FROM Suppliers INNER JOIN " +
                "Purchases ON Suppliers.SupplierID = Purchases.SupplierID " +
                "ORDER BY Purchases.PurchasesID DESC";
            var table = Context.GetDataTable(sqlQuery, "InventoryHistory", true);

            _dvHistory = new DataView(table);
            dgvReportOne.DataSource = _dvHistory;
        }

        #endregion

    }
}