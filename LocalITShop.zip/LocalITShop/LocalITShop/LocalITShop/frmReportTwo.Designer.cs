﻿namespace LocalITShop
{
    partial class frmReportTwo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlReportTwoTop = new System.Windows.Forms.Panel();
            this.lblInventoryReport = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.pnlReportTwoBottom = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dgvReportTwo = new System.Windows.Forms.DataGridView();
            this.pnlReportTwoTop.SuspendLayout();
            this.pnlReportTwoBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportTwo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlReportTwoTop
            // 
            this.pnlReportTwoTop.Controls.Add(this.lblInventoryReport);
            this.pnlReportTwoTop.Controls.Add(this.txtSearch);
            this.pnlReportTwoTop.Controls.Add(this.lblSearch);
            this.pnlReportTwoTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlReportTwoTop.Location = new System.Drawing.Point(0, 0);
            this.pnlReportTwoTop.Name = "pnlReportTwoTop";
            this.pnlReportTwoTop.Size = new System.Drawing.Size(800, 44);
            this.pnlReportTwoTop.TabIndex = 3;
            // 
            // lblInventoryReport
            // 
            this.lblInventoryReport.AutoSize = true;
            this.lblInventoryReport.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInventoryReport.Location = new System.Drawing.Point(12, 9);
            this.lblInventoryReport.Name = "lblInventoryReport";
            this.lblInventoryReport.Size = new System.Drawing.Size(165, 22);
            this.lblInventoryReport.TabIndex = 2;
            this.lblInventoryReport.Text = "Inventory Report";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(588, 8);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(202, 20);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged_1);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(509, 9);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(71, 20);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Search:";
            // 
            // pnlReportTwoBottom
            // 
            this.pnlReportTwoBottom.Controls.Add(this.btnExport);
            this.pnlReportTwoBottom.Controls.Add(this.btnClose);
            this.pnlReportTwoBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlReportTwoBottom.Location = new System.Drawing.Point(0, 374);
            this.pnlReportTwoBottom.Name = "pnlReportTwoBottom";
            this.pnlReportTwoBottom.Size = new System.Drawing.Size(800, 76);
            this.pnlReportTwoBottom.TabIndex = 4;
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(376, 16);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(204, 45);
            this.btnExport.TabIndex = 27;
            this.btnExport.Text = "Export To CSV";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(586, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(202, 45);
            this.btnClose.TabIndex = 26;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click_1);
            // 
            // dgvReportTwo
            // 
            this.dgvReportTwo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReportTwo.Location = new System.Drawing.Point(12, 50);
            this.dgvReportTwo.Name = "dgvReportTwo";
            this.dgvReportTwo.Size = new System.Drawing.Size(778, 318);
            this.dgvReportTwo.TabIndex = 5;
            // 
            // frmReportTwo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvReportTwo);
            this.Controls.Add(this.pnlReportTwoTop);
            this.Controls.Add(this.pnlReportTwoBottom);
            this.Name = "frmReportTwo";
            this.Text = "frmReportTwo";
            this.Load += new System.EventHandler(this.frmReportTwo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmReportTwo_Paint);
            this.pnlReportTwoTop.ResumeLayout(false);
            this.pnlReportTwoTop.PerformLayout();
            this.pnlReportTwoBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportTwo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlReportTwoTop;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Panel pnlReportTwoBottom;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblInventoryReport;
        private System.Windows.Forms.DataGridView dgvReportTwo;
    }
}