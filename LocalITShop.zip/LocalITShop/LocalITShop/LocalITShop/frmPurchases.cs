﻿using System;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmPurchases : Form
    {
        #region Form Events

        private void frmPurchases_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        #endregion

        #region Member Variables

        private long _PKID;
        private DataTable _purchasesTable, _purchasesListTable;
        private bool _isNew;

        #endregion

        #region Constructors

        public frmPurchases()
        {
            InitializeComponent();
            InitializeNewPurchase();
        }

        public frmPurchases(long pkId)
        {
            InitializeComponent();
            InitializeExistingPurchase(pkId);
        }

        private void InitializeNewPurchase()
        {
            _isNew = true;
            InitializeDataTable();
            gbxItems.Enabled = false;
        }

        private void InitializeExistingPurchase(long pkId)
        {
            _PKID = pkId;
            InitializeDataTable();
            gbxItems.Enabled = true;
            Debug.Assert(_PKID == 2);
        }

        private void InitializeDataTable()
        {
            _purchasesTable = Context.GetDataTable($"SELECT * FROM Purchases WHERE PurchasesID = {_PKID}", "Purchases");
            PopulateGrid();
        }

        #endregion

        #region Button Events

        private void cboSupplierName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboSupplierName.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmPurchases_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
            BindControls();
        }

        private void btnCreatePurchase_Click(object sender, EventArgs e)
        {
            // Before we create a child record, we will force our program to create a Parent record
            // based on the selections the user name in the Supplier combobox and PurchaseDate datetimepicker

            if (_isNew && _PKID <= 0)
            {
                var columnNames = "SupplierID, PurchaseDate, ReceivedDate";

                // When sending dates in SQL, we will use a string using the format of 'yyyy-MM-dd'
                var datePurchased = dtpPurchaseDate.Value.ToString("yyyy-MM-dd");
                var supplierID = long.Parse(cboSupplierName.SelectedValue.ToString());

                var columnValues = $"{supplierID}, '{datePurchased}', null";
                // Push the parent data to the database using the InsertParentTable of the Context class.
                // It will then return the PK of the newly created Parent record and we simply store
                // it in the _PKID variable.
                _PKID = Context.InsertParentTable("Purchases", columnNames, columnValues);
                // Display the _PKID value in the txtPurchaseID textbox.
                txtPurchaseID.Text = _PKID.ToString();
                // Call the InitializeDataTable method again to refresh it using the newly created parent
                // record from the database.
                InitializeDataTable();
                gbxItems.Enabled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dtpPurchaseDate.Text.Equals(" ") == false)
                _purchasesTable.Rows[0]["PurchaseDate"] = dtpPurchaseDate.Value.ToString("yyyy-MM-dd");

            // Always do an EndEdit before saving, otherwise the data will not persist in the database.
            _purchasesTable.Rows[0].EndEdit();
            Context.SaveDatabaseTable(_purchasesTable);
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete the item?", Settings.Default.ProjectName,
                MessageBoxButtons.YesNo) == DialogResult.Yes)
                try
                {
                    var PKID = long.Parse(dgvPurchasedItems[0, dgvPurchasedItems.CurrentCell.RowIndex].Value
                        .ToString());

                    // Use the DeleteRecord method of the Context class and pass the PK value
                    // to delete.
                    Context.DeleteRecord("PurchasesList", "PurchasesListID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record Exists.", Settings.Default.ProjectName);
                }
        }

        private void btnInsertItem_Click(object sender, EventArgs e)
        {
            var frm = new frmPurchasedItem(txtPurchaseID.Text);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                PopulateGrid();
                calculateTotalCost();
            }
        }

        private void dgvPurchasedItems_DoubleClick(object sender, EventArgs e)
        {
            if (dgvPurchasedItems.CurrentCell == null) return;

            var pkId = long.Parse(dgvPurchasedItems[0, dgvPurchasedItems.CurrentCell.RowIndex].Value.ToString());

            var frm = new frmPurchasedItem(pkId);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                PopulateGrid();
                calculateTotalCost();
            }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// This method is called to give us a Total Cost of the order. We are taking the Variables LineCost and LineQuantity
        /// and multiplying them, then saving the temporary value in RAM memory while adding additional LineCost and LineQuantities,
        /// eventually giving us the TotalCost of the order.
        /// </summary>
        private void calculateTotalCost()
        {
            decimal Cost = 0;

            foreach (DataGridViewRow dgv in dgvPurchasedItems.Rows)
                if (dgv.Cells["Cost"].Value != null)
                {
                    var LineCost = Convert.ToDecimal(dgv.Cells["Cost"].Value.ToString());
                    var LineQuantity = Convert.ToInt32(dgv.Cells["Quantity"].Value.ToString());
                    Cost += LineCost * LineQuantity;
                }

            txtPurchaseOrderTotal.Text = Cost.ToString();
            txtPurchaseOrderTotal.Focus();
        }

        /// <summary>
        /// The populate grid method is used to import information from the database to our data grid view, we are using a SQL query to simplify the coding.
        /// </summary>
        private void PopulateGrid()
        {
            var sqlQuery =
                "SELECT PurchasesList.PurchasesListID, Inventory.ProductName, Inventory.Brand, PurchasesList.Quantity, PurchasesList.Cost " +
                "FROM Inventory INNER JOIN " +
                "PurchasesList ON Inventory.ProductID = PurchasesList.ProductID " +
                $"WHERE PurchasesList.PurchasesID = {_PKID} " +
                "ORDER BY PurchasesList.PurchasesListID DESC";

            _purchasesListTable = Context.GetDataTable(sqlQuery, "PurchasesList");
            dgvPurchasedItems.DataSource = _purchasesListTable;
            calculateTotalCost();
        }

        /// <summary>
        ///     This method will populate the ComboBox by calling the GetDataTable of the Context
        ///     class and pass the table name of the source database table.
        /// </summary>
        private void PopulateComboBox()
        {
            // Get all the records from our source database table - Suppliers
            var dtb = Context.GetDataTable("Suppliers");

            // Set the ValueMember. This is the name of the PK field of the source database
            // table. This is the value taht will be stored in the database when the user selects
            // a row from the ComboBox.
            cboSupplierName.ValueMember = "SupplierID";

            // Set the DisplayMember. The DisplayMember is the name of the field of your source
            // database table that we want to use the display in the ComboBox.
            cboSupplierName.DisplayMember = "SupplierName";

            // Set the data source of the ComboBox by using the DataTable we have created above - dtb.
            cboSupplierName.DataSource = dtb;
        }

        /// <summary>
        /// This method is called to bind the value of the updated information to the combo box and update it in the database.
        /// </summary>
        private void BindControls()
        {
            txtPurchaseID.DataBindings.Add("Text", _purchasesTable, "PurchasesID");
            cboSupplierName.DataBindings.Add("SelectedValue", _purchasesTable, "SupplierID");
            dtpPurchaseDate.DataBindings.Add("Text", _purchasesTable, "PurchaseDate");
            dtpReceivedDate.DataBindings.Add("Text", _purchasesTable, "ReceivedDate");

            // When creating a NEW Purchase, we want to make sure that our Supplier ComboBox is empty
            // or nothing is selected and our DatePurchased DateTimePicker is also empty.
            if (_isNew)
                cboSupplierName.SelectedIndex = -1;

            if (_isNew || string.IsNullOrEmpty(_purchasesTable.Rows[0]["ReceivedDate"].ToString()))
            {
                dtpReceivedDate.Format = DateTimePickerFormat.Custom;
                dtpReceivedDate.CustomFormat = "";
            }
        }

        #endregion
    }
}