﻿using System;
using System.Windows.Forms;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmSettings : Form
    {
  
        #region Constructors

        public frmSettings()
        {
            InitializeComponent();
        }

        #endregion

        #region Form Events

        private void frmSettings_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        #endregion

        #region Button Events

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnChangeBackgroundColour_Click(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                // Save the Colour selected by the user in the ColourTheme
                Settings.Default.ColorTheme = colorDialog.Color;
                Settings.Default.Save();
            }
        }

        #endregion
        
    }
}