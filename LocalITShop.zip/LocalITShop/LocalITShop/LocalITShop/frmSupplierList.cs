﻿using System;
using System.Data;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmSupplierList : Form
    {
        #region Constructors

        public frmSupplierList()
        {
            InitializeComponent();
        }

        #endregion

        #region Member Variables

        #endregion

        #region Helper Methods

        private void PopulateGrid()
        {
            var dtb = new DataTable();
            dtb = Context.GetDataTable("Suppliers");
            dgvSupplierList.DataSource = dtb;
        }

        private void dgvSupplierList_DoubleClick(object sender, EventArgs e)
        {
            // If no current row or cell seleced, do nothing
            if (dgvSupplierList.CurrentCell == null) return;

            // Get the primary key ID of the selected row, which is in column 0
            var pkId = long.Parse(dgvSupplierList[0, dgvSupplierList.CurrentCell.RowIndex].Value.ToString());

            var frm = new frmSuppliers(pkId);
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lnkAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var frm = new frmSuppliers();
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var PKID = dgvSupplierList[0, dgvSupplierList.CurrentCell.RowIndex].Value.ToString();

            Context.DeleteRecord("Suppliers", "SupplierID", PKID);
            PopulateGrid();
        }

        #endregion

        #region Form Events

        private void frmSupplierList_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        private void frmSupplierList_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion
    }
}