﻿using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Controller;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmReportTwo : Form
    {
        #region Member Variables

        // Data Source of our grid. Easy to filter than DataTable.
        private DataView _dvProductHistory;

        #endregion

        #region Constructors

        public frmReportTwo()
        {
            InitializeComponent();
        }

        #endregion

        #region Form Events

        private void frmReportTwo_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        private void frmReportTwo_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {
            // The "%" is a wildcard. This means that whatever text we enter in txtSearch, we will search of SupplierName or ProductName contains the text entered.
            _dvProductHistory.RowFilter = $"ProductName LIKE '%{txtSearch.Text}%'";
            _dvProductHistory.RowFilter = $"Brand LIKE '%{txtSearch.Text}%'";
        }

        #endregion

        #region Button Events

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExport_Click_1(object sender, EventArgs e)
        {
            // Use StringBuilder to build CSV files
            var csv = new StringBuilder();

            // Loop through each row of the DataView History and we append each row to our csv string.
            foreach (DataRowView drv in _dvProductHistory)
                csv.AppendLine($"{drv["ProductName"]}, " +
                               $"{drv["Brand"]}, " +
                               $"{drv["Quantity"]}");

            // Writes the csv string in the Debug folder or where the .exe is located.
            // The name of the csv file is 'InventoryHistory'.
            File.WriteAllText(Application.StartupPath + @"\ProductHistory.csv", csv.ToString());
            MessageBox.Show("Export Completed.", Settings.Default.ProjectName);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// The populate grid method is used to import information from the database to our data grid view, we are using a SQL query to simplify the coding.
        /// </summary>
        private void PopulateGrid()
        {
            var sqlQuery = "SELECT * " +
                           "FROM Inventory " +
                           "ORDER BY Inventory.ProductName Desc";
            var table = Context.GetDataTable(sqlQuery, "ProductHistory", true);

            _dvProductHistory = new DataView(table);
            dgvReportTwo.DataSource = _dvProductHistory;
        }

        #endregion

    }
}