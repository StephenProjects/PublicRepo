﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using LocalITShop.Properties;

namespace LocalITShop
{
    public partial class frmMenu : Form
    {
        #region Member Variables

        #endregion

        #region Constructors

        public frmMenu()
        {
            InitializeComponent();
            Debug.Print("Program Started");
        }

        #endregion

        #region Form Events

        private void frmMenu_Paint(object sender, PaintEventArgs e)
        {
            // Read the new Colour selected and apply it to this form's back colour.
            BackColor = Settings.Default.ColorTheme;
        }

        #endregion

        #region Button Events

        private void btnReport1_Click(object sender, EventArgs e)
        {
            var frm = new frmReportOne();
            frm.ShowDialog();
        }

        private void btnReport2_Click(object sender, EventArgs e)
        {
            var frm = new frmReportTwo();
            frm.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            var frm = new frmSettings();
            frm.ShowDialog();
        }

        private void btnPurchases_Click(object sender, EventArgs e)
        {
            var frm = new frmPurchasesList();
            frm.ShowDialog();
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            var frm = new frmSupplierList();
            frm.ShowDialog();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            var frm = new frmInventoryList();
            frm.ShowDialog();
        }

        #endregion

        #region Helper Methods

        #endregion

    }
}