﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd.Models
{
    public class Topic
    {
        // This is the model for the answer table
        [DisplayName("Topic Id")]
        public int TopicId { get; set; }

        [DisplayName("Topic Name")]
        public string TopicName { get; set; }

        [DisplayName("Description")]
        public string TopicDescription { get; set; }

        [DisplayName("Picture")]
        public string TopicColourOfPicFileName { get; set; }

        // Fully qualifying Entity relationships
        public ICollection<Quiz> Quizzes { get; set; }
    }
}
