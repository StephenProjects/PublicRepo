﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace QuickQuizFrontEnd.Models
{
    public class Quiz
    {
        // This is the model for the quiz table
        [DisplayName("Quiz Id")]
        public int QuizId { get; set; }

        [DisplayName("Quiz Name")]
        public string QuizName { get; set; }

        [DisplayName("Description")]
        public string QuizDescription { get; set; }


        [DisplayName("Quiz Creator")]
        public string QuizCreator { get; set; }

        [DisplayName("Date")]
        public DateTime QuizCreationDate { get; set; }



        // Fully qualifying Entity relationships+
        public int TopicId { get; set; }
        public Topic Topic { get; set; }
        public ICollection<Question> Questions { get; set; }

        public IEnumerable<SelectListItem> Topics { get; set; }
        
    }
}
