﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd.Models
{
    public class Answer
    {
        // This is the model for the answer table
        [DisplayName("Answer Id")]
        public int AnswerId { get; set; }

        [DisplayName("Answer Letter")]
        public string AnswerLetter { get; set; }

        [DisplayName("Answer Text")]
        public string AnswerText { get; set; }

        [DisplayName("Check If Correct")]
        public bool IsCorrect { get; set; }

        // Fully qualifying a one to many relationship
        public int QuestionId { get; set; }
        public Question Question { get; set; }
        public IEnumerable<SelectListItem> Questions { get; set; }

    }
}
