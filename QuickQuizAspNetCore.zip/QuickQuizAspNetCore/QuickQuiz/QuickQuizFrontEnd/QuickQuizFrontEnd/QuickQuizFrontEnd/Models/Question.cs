﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd.Models
{
    public class Question
    {
        // This is the model for the question table
        [DisplayName("Question Id")]
        public int QuestionId { get; set; }

        [DisplayName("Question Number")]
        public string QuestionNumber { get; set; }

        [DisplayName("Question Text")]
        public string QuestionText { get; set; }



        // Fully qualifying a one to many relationship
        public int QuizId { get; set; }
        public Quiz Quiz { get; set; }
        public ICollection<Answer> Answers { get; set; }
        public IEnumerable<SelectListItem> Quizzes { get; set; }
    }
}

