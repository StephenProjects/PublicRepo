﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd
{
    public static class WebClient
    {
        public static HttpClient ApiClient = new HttpClient();

        static WebClient()
        {
            string apiUrl = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build()["ApiUrl"];

            ApiClient.BaseAddress = new Uri(apiUrl);
            ApiClient.DefaultRequestHeaders.Clear();
            ApiClient.DefaultRequestHeaders.Accept
                .Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }


        public static class ApiRequest<T>
        {
            public static T GetSingleRecord(string apiControllerName, int id)
            {
                HttpResponseMessage response = WebClient.ApiClient.GetAsync($"{apiControllerName}/{id}").Result;
                return response.Content.ReadAsAsync<T>().Result;
            }

            // GetListWithId
            public static List<T> GetListWithId(string apiControllerName, int id)
            {
                var response = WebClient.ApiClient.GetAsync($"{apiControllerName}/{id}").Result;
                return response.Content.ReadAsAsync<List<T>>().Result;
            }
            // GetList
            public static List<T> GetList(string apiControllerName)
            {
                var response = WebClient.ApiClient.GetAsync($"{apiControllerName}").Result;
                return response.Content.ReadAsAsync<List<T>>().Result;
            }
            // Post
            public static T Post(string apiControllerName, T entity)
            {
                var response = WebClient.ApiClient.PostAsJsonAsync(apiControllerName, entity).Result;
                return response.Content.ReadAsAsync<T>().Result;
            }
            // Put
            public static T Put(string apiControllerName, int id, T entity)
            {
                var response = WebClient.ApiClient.PutAsJsonAsync($"{apiControllerName}/{id}", entity).Result;
                return response.Content.ReadAsAsync<T>().Result;
            }
            // Delete
            public static T Delete(string apiControllerName, int id)
            {
                var response = WebClient.ApiClient.DeleteAsync($"{apiControllerName}/{id}").Result;
                return response.Content.ReadAsAsync<T>().Result;
            }
        }

    }
}
