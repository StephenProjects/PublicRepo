﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd
{
    // This Enum is used to store a list of predefined values
    public enum AssessmentType
    {
        Project,
        KnowledgeEvidence,
        WrittenTask,
        Test,
        Quiz
    }

}
