﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace QuickQuizFrontEnd.Controllers
{
    public class TopicController : Controller
    {
        #region Lists
        // Reference to our appsettings.json file
        IConfiguration _config;
        HttpClient _client;
        IWebHostEnvironment _environment;

        public TopicController(IConfiguration config, IWebHostEnvironment environment)
        {
            _config = config;
            _client = new HttpClient();
            _client.BaseAddress = _config.GetValue<Uri>("ApiUrl");
            _environment = environment;
        }

        // GET: TopicController
        // Send a request to the api to return a list
        // Display the list
        public ActionResult Index()
        {
            HttpResponseMessage response = _client.GetAsync("Topic").Result;
            var result = response.Content.ReadAsAsync<List<Topic>>().Result;
            return View(result);
        }

        #endregion

        #region Details

        // GET: TopicController/Details/5
        // Send a request to the api to return an individual record
        // Display the record
        public ActionResult Details(int id)
        {
            // Getting the form to auto-fill deleted data.
            var TopicList = WebClient.ApiRequest<Topic>.GetSingleRecord("Topic", id);

            // Return the data
            return View(TopicList);
        }

        #endregion

        #region Create

        // GET: TopicController/Create
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult Create()
        {

            return View();
        }

        // POST: TopicController/Create
        // Send a request to the API to create a topic
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Topic topic)
        {
            try
            {
                HttpResponseMessage response = _client.PostAsJsonAsync($"Topic", topic).Result;
                
                return RedirectToAction(nameof(Index));
            }
            catch(Exception e)
            {
                return View();
            }

        }

        #endregion

        #region Edit

        // GET: TopicController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Edit(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                var result = WebClient.ApiRequest<Topic>.GetSingleRecord("Topic", id);

                return View(result);
            }

            return RedirectToAction("Login", "Auth");
        }

        // POST: TopicController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow edit and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Topic topic)
        {
            if (TempData.Peek("Token") != null)
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization
                = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());
                topic = WebClient.ApiRequest<Topic>.Put("Topic", id, topic);
                return RedirectToAction("Index", "Topic");
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }



        #endregion

        #region Delete

        // GET: TopicController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Delete(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                var result = WebClient.ApiRequest<Topic>.GetSingleRecord("Topic", id);

                return View(result);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        // POST: TopicController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow delete and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Topic topic)
        {
            try
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization
                = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());
            var result = WebClient.ApiRequest<Topic>.Delete("Topic", id);
                return RedirectToAction("Index", "Topic");
            }
            catch
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        #endregion

        #region Helper Methods

        // Creation of a drag and drop feature
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            try
            {
                // This statement will check to see if a file has been dropped then save its location and name in seperate variables
                if(file.Length > 0)
                {
                    string folderRoot = Path.Combine(_environment.ContentRootPath, "wwwroot\\Uploads");
                    string fileName = file.FileName;
                    string filePath = Path.Combine(folderRoot, fileName);

                    // This method will take any uploaded file and drop it into the uploads folder.
                    using(var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    // If a file has successfully uploaded the user will receive a message
                    return Ok(new { success = true, message = "File successfully uploaded." });
                }
                // If a file has failed to be uploaded the user will receive a message
                return BadRequest(new { success = false, message = "File size too small or large." });
            }
            catch (Exception)
            {
                // If an error occurs the user will receive a message
                return BadRequest(new { success = false, message = "File failed to upload." });
            }
        }

        #endregion

    }
}
