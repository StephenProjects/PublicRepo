﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;

namespace QuickQuizFrontEnd.Controllers
{
    public class QuestionController : Controller
    {
        #region Lists

        public ActionResult QuestionsPerQuiz(int id)
        {
            // Get the data
            var QuestionList = WebClient.ApiRequest<Question>.GetListWithId("Question/QuestionsForQuiz", id);

            // return the data
            return View(QuestionList);
        }

        // GET: QuestionController
        // Send a request to the api to return a list
        // Display the list
        public ActionResult Index()
        {
            return View();
        }

        #endregion

        #region Details

        // GET: QuestionController/Details/5
        // Send a request to the api to return an individual record
        // Display the record
        public ActionResult Details(int id)
        {
            // Retrieve the Quiz
            var QuestionResult = WebClient.ApiRequest<Question>.GetSingleRecord("Question", id);

            // Retrieve the associated quiz and assign this Quiz to the quiz property of the Question
            QuestionResult.Quiz = WebClient.ApiRequest<Quiz>.GetSingleRecord("Quiz", QuestionResult.QuizId);

            return View(QuestionResult);
        }

        #endregion

        #region Create

        // GET: QuestionController/Create
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult Create(int id)
        {
            Question question = new Question();
            question.QuizId = id;
            return View(question);
        }

        // POST: QuestionController/Create
        // Send a request to the API to create a topic
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Question question)
        {
            try
            {
                question = WebClient.ApiRequest<Question>.Post("Question", question);

                return RedirectToAction(nameof(QuestionsPerQuiz), new { id = question.QuizId });
            }
            catch
            {
                return View(question);
            }
        }

        #endregion

        #region CreateFromMenu

        // GET: QuestionController/CreateFromMenu
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult CreateFromMenu()
        {
            Question question = new Question();

            // populate 'Questions' Property with a list of "Value, Text" SelectListItems
            question.Quizzes = GetQuizzes();

            // Return the empty question with the list for the dropdownlist
            return View(question);
        }


        // POST: QuestionController/CreateFromMenu
        // Send a request to the API to create a quiz
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateFromMenu(Question question)
        {
            try
            {
                question = WebClient.ApiRequest<Question>.Post("Question", question);
                return RedirectToAction(nameof(QuestionsPerQuiz), new { id = question.QuizId});
            }
            catch
            {
                return View(question);
            }
        }

        #endregion

        #region Edit

        // GET: QuestionController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Edit(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                var result = WebClient.ApiRequest<Question>.GetSingleRecord("Question", id);

                return View(result);
            }

            return RedirectToAction("Login", "Auth");
        }

        // POST: QuestionController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow edit and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Question question)
        {
            try
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization
                = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());
                question = WebClient.ApiRequest<Question>.Put("Question", id, question);
                return RedirectToAction(nameof(QuestionsPerQuiz), new { id = question.QuizId });
            }
            catch
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        #endregion

        #region Delete

        // GET: QuestionController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Delete(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                var result = WebClient.ApiRequest<Question>.GetSingleRecord("Question", id);

                return View(result);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        // POST: QuestionController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow delete and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Question question)
        {
            try
            {
                // If we have a token
                if (TempData.Peek("Token") != null)
                {
                    // Add our token to the Authorization Header
                    WebClient.ApiClient.DefaultRequestHeaders.Authorization
                        = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                    // Send our updated values to the API
                    var QuizList = WebClient.ApiRequest<Question>.Delete("Question", id);

                    // Redirect to our list

                    // TODO Note the changes h ere - we need to set the API up to return the Tafeclass back to us on delete.
                    // The issue is that our form only returns the id to us, we need to know the TeacherId of the 
                    // Deleted Tafeclass to correctly redirect back to the List

                    return RedirectToAction(nameof(QuestionsPerQuiz), new { id = QuizList.QuizId});
                }
                else
                {
                    // Redirect to the login page
                    return RedirectToAction("Login", "Auth");
                }
            }
            catch
            {
                return View();
            }
        }

        #endregion

        #region Helper Methods

        // This method creates a list of questions with filtered results
        // Make a request to the API and return a a list of quizzes
        // Instantiate a list of quizzes with filtered results including id and name
        private IEnumerable<SelectListItem> GetQuizzes()
        {
            var result = WebClient.ApiRequest<Quiz>.GetList("Quiz");

            // filter the returned list and create a new list of SelectListItems from the items returned
            List<SelectListItem> quizzes = result.OrderBy(t => t.QuizName)
                                            .Select(o => new SelectListItem
                                            {
                                                Value = o.QuizId.ToString(),
                                                Text = o.QuizName
                                            }).ToList();

            // return the items as a new SelectList
            return new SelectList(quizzes, "Value", "Text");
        }

        #endregion

    }
}