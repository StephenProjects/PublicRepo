﻿using ChartJSCore.Helpers;
using ChartJSCore.Models;
using CsvHelper;
using Microsoft.AspNetCore.Mvc;
using QuickQuizApi.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd.Controllers
{
    // This controller is to generate a set of data to display as a graph
    public class ReportController : Controller
    {
        // Save the report as a variable
        // Select the desired columns and save them as their own variables
        // Instantiate a "Chart" and set it as a type " Bar Chart "
        // Populate Chart
        // Display Chart on a selected page
        public IActionResult QuizzesPerTopicReport()
        {

            var reportData = WebClient.ApiRequest<TopicQuizCountReport>.GetList("Report/quizreport");

            var topicNames = reportData.Select(c => c.TopicName).ToList();

            var numberNumberOfQuizzes = reportData.Select(c => (double?)c.NumberOfQuizzes).ToList();

            Chart chart = new Chart();

            chart.Type = Enums.ChartType.Bar;

            ChartJSCore.Models.Data chartData = new ChartJSCore.Models.Data();

            chartData.Labels = topicNames;

            List<ChartColor> chartColors = new List<ChartColor>()
            {
                ChartColor.FromRgba(255, 25, 25, 0.5),
                ChartColor.FromRgba(25, 25, 255, 0.5),
                ChartColor.FromRgba(25, 255, 25, 0.5),
            };

            BarDataset dataSet = new BarDataset()
            {
                Label = "Number of Quizzes",
                Data = numberNumberOfQuizzes,
                Type = Enums.ChartType.Bar,
                BackgroundColor = chartColors,
                BorderColor = chartColors
            };

            chartData.Datasets = new List<Dataset>();
            chartData.Datasets.Add(dataSet);

            chart.Data = chartData;

            ViewData["Chart"] = chart;

            return View();

        }

        // This method is used to export data to a .csv file
        // Save the Chart data as its own variable
        // Create a MemoryStream
        // Write the data to a CSV file and save the variable
        public IActionResult QuizzesPerTopicReportExport()
        {
            var reportData = WebClient.ApiRequest<TopicQuizCountReport>.GetList("Report/quizreport");

            var stream = new MemoryStream();

            using(var writeFile = new StreamWriter(stream, leaveOpen:true))
            {
                var csv = new CsvWriter(writeFile, CultureInfo.CurrentCulture, true);
                csv.WriteRecords(reportData);

                // Reset the memory stream position to 0 after each use.
                stream.Position = 0;

                return File(stream, "application/octet-stream", $"ReportData_{DateTime.Now.ToString("ddMMM_HHmmss")}.csv");
            }

        }

    }
}
