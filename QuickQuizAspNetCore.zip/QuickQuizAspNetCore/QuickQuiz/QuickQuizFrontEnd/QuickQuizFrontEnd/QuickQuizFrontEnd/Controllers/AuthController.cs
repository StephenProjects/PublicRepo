﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace QuickQuizFrontEnd.Controllers
{
    // This controller is used to enable admin priviledges
    public class AuthController : Controller
    {

        // The logout function will automatically clear the data and return the user to the home page
        [HttpGet]
        public IActionResult Logout()
        {
            TempData.Clear();
            return RedirectToAction("Index", "Home");
        }

        // The login button will return an empty view of the login page
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // This login function is for the admin
        // When the user logs in using the admin details then a token is generated
        // If the username and password are correct then a token is given to the user and they are redirected to the home page
        [HttpPost]
        public IActionResult Login(UserInfo userInfo)
        {
            if (userInfo != null && !String.IsNullOrEmpty(userInfo.UserName) && !String.IsNullOrEmpty(userInfo.Password))
            {
                var result = WebClient.ApiClient.PostAsJsonAsync("Token/GenerateToken", userInfo).Result;

                if(result.IsSuccessStatusCode)
                {
                    var token = result.Content.ReadAsStringAsync().Result;

                    TempData["Token"] = token.Trim('/').Trim('"');
                    TempData["UserName"] = userInfo.UserName;
                    TempData.Keep();

                    return RedirectToAction("Index", "Home");
                }

                return View();

            }

            return View();

        }
    }
}
