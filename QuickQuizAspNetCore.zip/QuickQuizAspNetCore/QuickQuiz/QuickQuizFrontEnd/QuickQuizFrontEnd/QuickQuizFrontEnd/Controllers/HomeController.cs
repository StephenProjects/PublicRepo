﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace QuickQuizFrontEnd.Controllers
{
    public class HomeController : Controller

    {
        // This controller is used as a landing page
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // GET: HomeController/CreateUsername
        public IActionResult CreateUsername()
        {
            // Return the empty Username with the list for the dropdownlist
            return View();
        }


        // POST: HomeController/CreateUsername
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateUsername(UserInfo userInfo)
        {
            try
            {
                // Take username and save in temp data THEN redirect
                TempData["UserName"] = userInfo.UserName;
                TempData.Keep();

                // Redirect to the quiz creator
                return RedirectToAction("CreateFromMenu", "Quiz");
            }
            catch
            {
                return View();
            }
        }

        public IActionResult Help()
        {
            return View();
        }

    }
}
