﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;

namespace QuickQuizFrontEnd.Controllers
{
    public class AnswerController : Controller
    {
        #region Lists
        public ActionResult AnswersPerQuestion(int id)
        {
            // Get the data
            var AnswerList = WebClient.ApiRequest<Answer>.GetListWithId("Answer/AnswersForQuestion", id);

            return View(AnswerList);
        }

        // GET: AnswerController
        // Send a request to the api to return a list
        // Display the list
        public ActionResult Index()
        {
            return View();
        }

        #endregion

        #region Details

        // GET: AnswerController/Details/5
        // Send a request to the api to return an individual record
        // Display the record
        public ActionResult Details(int id)
        {
            // Retrieve the Answer
            var AnswerResult = WebClient.ApiRequest<Answer>.GetSingleRecord("Answer", id);

            // Retrieve the associated question and assign this question to the answer property of the question
            AnswerResult.Question = WebClient.ApiRequest<Question>.GetSingleRecord("Question", AnswerResult.QuestionId);

            return View(AnswerResult);
        }

        #endregion

        #region Create

        // GET: AnswerController/Create
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult Create(int id)
        {
            Answer answer = new Answer();
            answer.QuestionId = id;
            return View(answer);
        }

        // POST: AnswerController/Create
        // Send a request to the API to create a topic
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Answer answer)
        {
            try
            {
                answer = WebClient.ApiRequest<Answer>.Post("Answer", answer);

                return RedirectToAction(nameof(AnswersPerQuestion), new { id = answer.QuestionId});
            }
            catch
            {
                return View(answer);
            }
        }

        #endregion

        #region CreateFromMenu

        // GET: AnswerController/CreateFromMenu
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult CreateFromMenu()
        {
            Answer answer = new Answer();
            answer.Questions = GetQuestions();
            return View(answer);
        }


        // POST: AnswerController/CreateFromMenu
        // Send a request to the API to create a quiz
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateFromMenu(Answer answer)
        {
            try
            {
                answer = WebClient.ApiRequest<Answer>.Post("Answer", answer);
                return RedirectToAction(nameof(AnswersPerQuestion), new { id = answer.QuestionId });
            }
            catch
            {
                return View(answer);
            }
        }

        #endregion

        #region Edit

        // GET: AnswerController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Edit(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                var result = WebClient.ApiRequest<Answer>.GetSingleRecord("Answer", id);

                return View(result);
            }

            return RedirectToAction("Login", "Auth");
        }

        // POST: AnswerController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow edit and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Answer answer)
        {
            try
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization
                = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());
                answer = WebClient.ApiRequest<Answer>.Put("Answer", id, answer);
                return RedirectToAction(nameof(AnswersPerQuestion), new { id = answer.QuestionId });
            }
            catch
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        #endregion

        #region Delete

        // GET: AnswerController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Delete(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                var result = WebClient.ApiRequest<Answer>.GetSingleRecord("Answer", id);

                return View(result);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        // POST: AnswerController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow delete and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Answer answer)
        {
            try
            {
                // If we have a token
                if (TempData.Peek("Token") != null)
                {
                    // Add our token to the Authorization Header
                    WebClient.ApiClient.DefaultRequestHeaders.Authorization
                        = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                    // Send our updated values to the API
                    var AnswerList = WebClient.ApiRequest<Answer>.Delete("Answer", id);

                    // Redirect to our list

                    // TODO Note the changes here - we need to set the API up to return the Tafeclass back to us on delete.
                    // The issue is that our form only returns the id to us, we need to know the TeacherId of the 
                    // Deleted Tafeclass to correctly redirect back to the List

                    return RedirectToAction(nameof(AnswersPerQuestion), new { id = AnswerList.QuestionId });
                }
                else
                {
                    // Redirect to the login page
                    return RedirectToAction("Login", "Auth");
                }
            }
            catch
            {
                return RedirectToAction(nameof(AnswersPerQuestion), new { id = answer.QuestionId });
            }
        }

        #endregion

        #region Helper Methods

        // This method creates a list of questions with filtered results
        // Make a request to the API and return a a list of questions
        // Instantiate a list of questions with filtered results including id and name
        private IEnumerable<SelectListItem> GetQuestions()
        {

            var result = WebClient.ApiRequest<Question>.GetList("Question");

            // filter the returned list and create a new list of SelectListItems from the items returned
            List<SelectListItem> questions = result.OrderBy(t => t.QuestionNumber)
                                            .Select(o => new SelectListItem
                                            {
                                                Value = o.QuestionId.ToString(),
                                                Text = o.QuestionNumber
                                            }).ToList();

            // return the items as a new SelectList
            return new SelectList(questions, "Value", "Text");
        }

        #endregion

    }
}
