﻿using QuickQuizFrontEnd.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;

namespace QuickQuizFrontEnd.Controllers
{
    public class QuizController : Controller
    {

        #region Lists

        /// <summary>
        /// This method will direct the user to a page which displays a list of quizzes for a particular topic
        /// </summary>
        /// <param name="id"></param>
        /// <returns>This method returns a list of quizzes</returns>
        public ActionResult QuizzesPerTopic(int id)
        {
            // Get the data
            var QuizList = WebClient.ApiRequest<Quiz>.GetListWithId("Quiz/QuizzesForTopic", id);

            // return the data
            return View(QuizList);
        }

        // GET: QuizController
        public ActionResult Index()
        {
            return View();
        }

        #endregion

        #region Details

        // GET: QuizController/Details/5
        // Send a request to the api to return an individual record
        // Display the record
        public ActionResult Details(int id)
        {
            // Retrieve the Quiz
            var QuizResult = WebClient.ApiRequest<Quiz>.GetSingleRecord("Quiz", id);

            // Retrieve the associated Topic and assign this Topic to the topic property of Quiz
            QuizResult.Topic = WebClient.ApiRequest<Topic>.GetSingleRecord("Topic", QuizResult.TopicId);

            return View(QuizResult);
        }

        #endregion

        #region Create

        // GET: QuizController/Create
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult Create(int id)
        {
            Quiz quiz = new Quiz();
            quiz.TopicId = id;
            return View(quiz);
        }

        // POST: QuizController/Create
        // Send a request to the API to create a quiz
        // Automatically redirect the user to the previous page
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Quiz quiz)
        {
            try
            {
                quiz = WebClient.ApiRequest<Quiz>.Post("Quiz", quiz);

                return RedirectToAction(nameof(QuizzesPerTopic), new { id = quiz.TopicId });
            }
            catch
            {
                return View(quiz);
            }
        }

        #endregion

        #region CreateFromMenu

        // GET: QuizController/CreateFromMenu
        // Send a request to the api to request a landing page
        // Display the landing page
        public ActionResult CreateFromMenu()
        {
            Quiz quiz = new Quiz();
            // populate 'Quizzes' Property with a list of "Value, Text" SelectListItems
            quiz.Topics = GetTopics();

            // Automatically fill in the creator name field when the quiz creator has selected a name
            string Name;

            if (TempData.ContainsKey("UserName"))
            {
                Name = TempData.Peek("UserName").ToString();
                quiz.QuizCreator = Name;
            }

            // Return the empty quiz with the list for the dropdownlist
            return View(quiz);
        }

        // POST: QuizController/CreateFromMenu
        // Send a request to the API to create a quiz
        // Automatically redirect the user to the previous page

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateFromMenu(Quiz quiz)
        {
            try
            {
                quiz = WebClient.ApiRequest<Quiz>.Post("Quiz", quiz);
                return RedirectToAction(nameof(QuizzesPerTopic), new { id = quiz.TopicId });
            }
            catch
            {
                return View(quiz);
            }

        }


        #endregion

        #region Edit

        // GET: QuizController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Edit(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                var result = WebClient.ApiRequest<Answer>.GetSingleRecord("Quiz", id);

                return View(result);
            }

            return RedirectToAction("Login", "Auth");
        }

        // POST: QuizController/Edit/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // If the user is an admin allow edit and save to database
        // Return admin to previous page
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Quiz quiz)
        {
            try
            {
                WebClient.ApiClient.DefaultRequestHeaders.Authorization
                = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());
                quiz = WebClient.ApiRequest<Quiz>.Put("Quiz", id, quiz);
                return RedirectToAction(nameof(QuizzesPerTopic), new { id = quiz.TopicId });
            }
            catch
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        #endregion

        #region Delete

        // GET: QuizController/Delete/5
        // Activate authorization to allow only admin to access this page
        // Peek to see if the user has generated a token
        // Return the result if the user is an admin
        // Else redirect to admin login page
        [Authorize]
        public ActionResult Delete(int id)
        {
            if (TempData.Peek("Token") != null)
            {
                var result = WebClient.ApiRequest<Quiz>.GetSingleRecord("Quiz", id);

                return View(result);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        // POST: QuizController/Delete/5
        /// <summary>
        /// Activate authorization to allow only admin to access this page
        /// Peek to see if the user has generated a token
        /// If the user is an admin allow delete and save to database
        /// </summary>
        /// <param name="id"></param>
        /// <param name="quiz"></param>
        /// <returns>Return admin to previous page</returns>
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Quiz quiz)
        {
            try
            {
                // If we have a token
                if (TempData.Peek("Token") != null)
                {
                    // Add our token to the Authorization Header
                    WebClient.ApiClient.DefaultRequestHeaders.Authorization
                        = new AuthenticationHeaderValue("Bearer", TempData.Peek("Token").ToString());

                    // Send our updated values to the API
                    var QuizList = WebClient.ApiRequest<Quiz>.Delete("Quiz", id);

                    // Redirect to our list

                    // TODO Note the changes here - we need to set the API up to return the Quiz back to us on delete.
                    // The issue is that our form only returns the id to us, we need to know the Topic of the 
                    // Deleted Quiz to correctly redirect back to the List

                    return RedirectToAction(nameof(QuizzesPerTopic), new { id = QuizList.TopicId });
                }
                else
                {
                    // Redirect to the login page
                    return RedirectToAction("Login", "Auth");
                }
            }
            catch
            {
                return RedirectToAction(nameof(QuizzesPerTopic), new { id = quiz.TopicId });
            }
        }

        #endregion

        #region Helper Methods

        // This method creates a list of questions with filtered results
        // Make a request to the API and return a a list of quizzes
        // Instantiate a list of quizzes with filtered results including id and name
        private IEnumerable<SelectListItem> GetTopics()
        {

            var result = WebClient.ApiRequest<Topic>.GetList("Topic");

            // filter the returned list and create a new list of SelectListItems from the items returned
            List<SelectListItem> topics = result.OrderBy(t => t.TopicName)
                                            .Select(o => new SelectListItem
                                            {
                                                Value = o.TopicId.ToString(),
                                                Text = o.TopicName
                                            }).ToList();

            // return the items as a new SelectList
            return new SelectList(topics, "Value", "Text");
        }

        #endregion

    }
}
