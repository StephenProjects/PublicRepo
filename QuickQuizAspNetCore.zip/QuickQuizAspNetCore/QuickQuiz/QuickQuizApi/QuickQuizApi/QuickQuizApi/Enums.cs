﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi
{
    // This Enum is used to store a list of predefined values
    public enum AnswerType
    {
        Project,
        KnowledgeEvidence,
        WrittenTask,
        Test,
        Quiz
    }
}
