﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models
{
    public class Quiz
    {
        // This model is used to store the quiz data in the database
        public int QuizId { get; set; }

        public string QuizCreator { get; set; }
        public DateTime QuizCreationDate { get; set; }
        public string QuizName { get; set; }
        public string QuizDescription { get; set; }


        // Fully qualifying Entity relationships
        public int TopicId { get; set; }
        public Topic Topic { get; set; }
        public ICollection<Question> Questions { get; set; }

    }
}
