﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models
{
    public class Topic
    {
        // This model is used to store the topic data in the database
        public int TopicId { get; set; }

        public string TopicName { get; set; }
        public string TopicDescription { get; set; }
        public string TopicColourOfPicFileName { get; set; }

        // Fully qualifying Entity relationships
        public ICollection<Quiz> Quizzes { get; set; }
    }
}
