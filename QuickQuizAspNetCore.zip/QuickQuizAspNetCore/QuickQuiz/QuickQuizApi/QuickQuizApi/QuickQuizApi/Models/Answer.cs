﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models
{
    public class Answer
    {
        // This model is used to store the answer data in the database
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
        public string AnswerLetter { get; set; }
        public bool IsCorrect { get; set; }
        public int QuestionId { get; set; }
        public Question Question { get; set; }
    }
}
