﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models.ViewModels
{
    public class TopicQuizCountReport
    {
        public string TopicName { get; set; }
        public string QuizId { get; set; }
        public string QuizName { get; set; }
        public int NumberOfQuizzes { get; set; }

    }
}