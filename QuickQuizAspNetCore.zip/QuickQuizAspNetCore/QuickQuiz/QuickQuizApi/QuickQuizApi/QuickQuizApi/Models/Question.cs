﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models
{
    public class Question
    {
        // This model is used to store the question data in the database
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string QuestionNumber { get; set; }


        // Fully qualifying a one to many relationship
        public int QuizId { get; set; }
        public Quiz Quiz { get; set; }
        public ICollection<Answer> Answers { get; set; }
    }
}
