﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Models
{
    public class QuickQuizContext : DbContext
    {
        // This class has been created to seed data into the database tables

        public QuickQuizContext(DbContextOptions options) : base(options)
        {

        }

        // These are the tables to be saved
        public DbSet<Topic> Topics { get; set; }
        public DbSet<Quiz> Quizzes { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<UserInfo> UserInfos { get; set; }
        public object UserInfo { get; internal set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // The seeded data sets for the database tables

            modelBuilder.Entity<UserInfo>().HasData(
                new UserInfo
                {
                    UserInfoId = 1,
                    UserName = "Steve",
                    Password = "1234"
                });


            // Seeding Data for the Topic Table
            modelBuilder.Entity<Topic>().HasData(
                new Topic
                {
                    TopicId = 1,
                    TopicDescription = "The state of being protected against the criminal or unauthorized use of electronic data, or the measures taken to achieve this.",
                    TopicName = "Cyber Security"
                },
                new Topic
                {
                    TopicId = 2,
                    TopicDescription = "The study or use of systems for storing, retrieving, and sending information.",
                    TopicName = "Information Technology"
                });

            // Seeding data for the Quiz table
            modelBuilder.Entity<Quiz>().HasData(
                new Quiz
                {
                    QuizId = 1,
                    QuizName = "ASP Net",
                    QuizCreator = "Stephen",
                    QuizCreationDate = DateTime.Now,
                    QuizDescription = "The security of ASP.Net",
                    TopicId = 1
                },
                new Quiz
                {
                    QuizId = 2,
                    QuizName = "HTTPS",
                    QuizCreator = "Shaun",
                    QuizCreationDate = DateTime.Now,
                    QuizDescription = "The security of HTTPS",
                    TopicId = 1
                },
                new Quiz
                {
                    QuizId = 3,
                    QuizName = "IT",
                    QuizCreator = "Harry",
                    QuizCreationDate = DateTime.Now,
                    QuizDescription = "What is the definition of IT",
                    TopicId = 2
                });

            // Seeding data for the Question table
            modelBuilder.Entity<Question>().HasData(
                new Question
                {
                    QuestionId = 1,
                    QuestionText = "ICTPRG532",
                    QuestionNumber = "Question 1",
                    QuizId = 1
                },
                new Question
                {
                    QuestionId = 2,
                    QuestionText = "ICTPRG532",
                    QuestionNumber = "Question 2",
                    QuizId = 1
                },
                new Question
                {
                    QuestionId = 3,
                    QuestionText = "ICTPRG532",
                    QuestionNumber = "Question 3",
                    QuizId = 2
                },
                new Question
                {
                    QuestionId = 4,
                    QuestionText = "ICTPRG532",
                    QuestionNumber = "Question 4",
                    QuizId = 3
                });

            // Seeding data for the Answer Table
            modelBuilder.Entity<Answer>().HasData(
                new Answer
                {
                    AnswerId = 1,
                    AnswerText = "This is the text for the first answer",
                    AnswerLetter = "A",
                    QuestionId = 1
                },
                new Answer
                {
                    AnswerId = 2,
                    AnswerText = "This is the text for the second answer",
                    AnswerLetter = "B",
                    QuestionId = 1
                },
                new Answer
                {
                    AnswerId = 3,
                    AnswerText = "This is the text for the third answer",
                    AnswerLetter = "C",
                    QuestionId = 1
                },
                new Answer
                {
                    AnswerId = 4,
                    AnswerText = "This is the text for the fourth answer",
                    AnswerLetter = "D",
                    QuestionId = 1
                },
                new Answer
                {
                    AnswerId = 5,
                    AnswerText = "This is the text for the fifth answer",
                    AnswerLetter = "E",
                    QuestionId = 1
                });

        }
    }
}
