﻿using QuickQuizApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickQuizApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnswerController : ControllerBase
    {
        private QuickQuizContext _context;
        public AnswerController(QuickQuizContext context)
        {
            _context = context;
        }

        #region CRUD methods

        // GET: api/<AnswerController>
        [HttpGet]
        public IEnumerable<Answer> Get()
        {
            // Return a list of answers
            return _context.Answers.ToList();
        }

        // GET api/<AnswerController>/5
        [HttpGet("{id}")]
        public ActionResult<Answer> Get(int id)
        {
            // Return an individual id that is connected to an answer
            Answer answer = _context.Answers.Find(id);
            if (answer != null)
            {
                return Ok(answer);
            }
            else
            {
                return NotFound();
            }
        }

        // POST api/<AnswerController>
        [HttpPost]
        public IActionResult Post(Answer answer)
        {
            if (answer != null)
            {
                // Create and save an answer
                _context.Add(answer);
                _context.SaveChanges();

                // Automatically redirect user to previous page
                return CreatedAtAction("Post", answer);
            }
            return BadRequest();
        }

        // PUT api/<AnswerController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Answer answer)
        {
            if (answer != null && answer.AnswerId == id)
            {
                // Edit and save an individual answer
                _context.Answers.Update(answer);
                _context.SaveChanges();
                return Ok(answer);
            }
            return BadRequest();
        }

        // DELETE api/<AnswerController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Answer answer = _context.Answers.Find(id);
            if (answer != null)
            {
                // Delete and save changes to the database
                _context.Answers.Remove(answer);
                _context.SaveChanges();

                // Automatically redirect user to previous page
                return Ok(answer);
            }
            return NotFound();
        }

        #endregion

        #region Custom Endpoints

        // Custom Methods - Using .Include and specifying a property of the model tells entityframework to 
        // query and return that property with the overall query

        [Route("AnswersForQuestion/{id}")]
        public ActionResult<IEnumerable<Answer>> AnswersForQuestion(int id)
        {
            IEnumerable<Answer> answersForQuestion =  _context.Answers.Include(c => c.Question).Where(c => c.QuestionId == id);
        
            if(answersForQuestion != null)
            {
                return Ok(answersForQuestion);
            }
            else
            {
                return NotFound();
            }
        }
        #endregion


    }
}
