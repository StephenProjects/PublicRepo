﻿using QuickQuizApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TopicController : ControllerBase
    {
        private QuickQuizContext _context;
        public TopicController(QuickQuizContext context)
        {
            _context = context;
        }

        #region CRUD methods

        // GET: api/<TopicController>
        // Return a list of questions
        [HttpGet]
        public IEnumerable<Topic> Get()
        {
            return _context.Topics.ToList();
        }

        // GET api/<TopicController>/5
        // Return an individual id that is connected to an question
        [HttpGet("{id}")]
        public ActionResult<Topic> Get(int id)
        {
            Topic topic = _context.Topics.Find(id);
            if(topic != null)
            {
                return Ok(topic);
            }
            else
            {
                return NotFound();
            }
        }

        // POST api/<TopicController>
        // Create and Save changes to the database
        // Automatically redirect user to previous page
        [HttpPost]
        public IActionResult Post(Topic topic)
        {
            if(topic != null)
            {
                // _context.Add(topic);
                _context.Add(topic);
                _context.SaveChanges();
                return CreatedAtAction("Post", topic);
            }
            return BadRequest();
        }

        // PUT api/<TopicController>/5
        // Edit and Save changes to the database
        // Automatically redirect user to previous page
        [Authorize]
        [HttpPut("{id}")]
        public IActionResult Put(int id, Topic topic)
        {
            if (topic != null && topic.TopicId == id)
            {
                _context.Topics.Update(topic);
                _context.SaveChanges();
                return Ok(topic);
            }
            return BadRequest();
        }

        // DELETE api/<TopicController>/5
        // Delete and Save changes to the database
        // Automatically redirect user to previous page
        [Authorize]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Topic topic = _context.Topics.Find(id);
            if(topic != null)
            {
                _context.Topics.Remove(topic);
                _context.SaveChanges();
                return Ok(topic);
            }
            return NotFound();
        }

        #endregion

        #region Custom Endpoints

        // Custom Methods - Using .Include and specifying a property of the model tells entityframework to 
        // query and return that property with the overall query

        [Route("TopicsWithQuizzes")]
        public ActionResult<IEnumerable<Topic>> TopicsWithQuizzes()
        {
            return _context.Topics.Include(c => c.Quizzes).ToList();
        }
        
        [Route("TopicsWithQuizzes/{id}")]
        public ActionResult<Topic> TopicsWithQuizzes(int id)
        {
            return _context.Topics.Include(c => c.Quizzes).Where(c => c.TopicId == id).FirstOrDefault();
        }
        #endregion

    }
}