﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuickQuizApi.Models;
using QuickQuizApi.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuickQuizApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        QuickQuizContext _context;

        public ReportController(QuickQuizContext context)
        {
            _context = context;
        }

       [Route("quizreport")]
       // Creating a list of quizzes
       // Save the list to a variable
       // For each quiz in the list add it to a report
       // Select the fields to display in the report
       // Display the generated report
        public IList<TopicQuizCountReport> QuizReport()
        {
            var quizReports = new List<TopicQuizCountReport>();

            List<Quiz> quizList = _context.Quizzes.ToList();

            foreach(var topic in _context.Topics.ToList())
            {
                var quizReport = new TopicQuizCountReport
                {
                    TopicName = topic.TopicName,
                    NumberOfQuizzes = quizList.Where(c => c.TopicId == topic.TopicId).Count()
                };
                quizReports.Add(quizReport);
            }
            return quizReports;

        }

    }
}
