﻿using QuickQuizApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickQuizApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuizController : ControllerBase
    {
        
        private QuickQuizContext _context;
        public QuizController(QuickQuizContext context)
        {
            _context = context;
        }

        #region CRUD methods

        /// <summary>
        /// GET request to the API<QuizController>
        /// </summary>
        /// <returns>Return a list of quizzes</returns>
        [HttpGet]
        public IEnumerable<Quiz> Get()
        {
            return _context.Quizzes.ToList();
        }

        /// <summary>
        /// GET request to the API for a single id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return an individual id that is connected to a quiz</returns>
        [HttpGet("{id}")]
        public ActionResult<Quiz> Get(int id)
        {
            Quiz quiz = _context.Quizzes.Find(id);
            if (quiz != null)
            {
                return Ok(quiz);
            }
            else
            {
                return NotFound();
            }
        }

        /// <summary>
        /// POST api/<QuizController>
        /// Create and Save changes to the database
        /// </summary>
        /// <param name="quiz"></param>
        /// <returns>Automatically redirect user to previous page</returns>
        [HttpPost]
        public IActionResult Post(Quiz quiz)
        {
            if (quiz != null)
            {
                _context.Add(quiz);
                _context.SaveChanges();
                return CreatedAtAction("Post", quiz);
            }
            return BadRequest();
        }

        /// <summary>
        /// PUT api/<QuizController>/5
        /// Edit and Save changes to the database
        /// </summary>
        /// <param name="id"></param>
        /// <param name="quiz"></param>
        /// <returns>Automatically redirect user to previous page</returns>
        [HttpPut("{id}")]
        public IActionResult Put(int id, Quiz quiz)
        {
            if (quiz != null && quiz.QuizId == id)
            {
                _context.Quizzes.Update(quiz);
                _context.SaveChanges();
                return Ok(quiz);
            }
            return BadRequest();
        }

        /// <summary>
        /// DELETE api/<QuizController>/5
        /// Delete and Save changes to the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Automatically redirect user to previous page</returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Quiz quiz = _context.Quizzes.Find(id);
            if (quiz != null)
            {
                _context.Quizzes.Remove(quiz);
                _context.SaveChanges();
                return Ok(quiz);
            }
            return NotFound();
        }
        #endregion

        #region Custom Endpoints

        // Custom Methods - Using .Include and specifying a property of the model tells entityframework to 
        // query and return that property with the overall query

        [Route("QuizzesWithQuestions")]
        public ActionResult<IEnumerable<Quiz>> QuizzesWithQuestions()
        {
            return _context.Quizzes.Include(c => c.Questions).ToList();
        }

        [Route("QuizzesForTopic/{id}")]
        public ActionResult<IEnumerable<Quiz>> QuizzesForTopic(int id)
        {

            IEnumerable<Quiz> quizzesForTopic = _context.Quizzes.Include(c => c.Topic).Where(c => c.TopicId == id);
            if(quizzesForTopic != null)
            {
                return Ok(quizzesForTopic);
            }
            else
            {
                return NotFound();
            }
        }

        #endregion
    }
}
