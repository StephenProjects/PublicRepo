﻿using QuickQuizApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickQuizApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private QuickQuizContext _context;
        public QuestionController(QuickQuizContext context)
        {
            _context = context;
        }

        #region CRUD methods

        // GET: api/<QuestionController>
        [HttpGet]
        public IEnumerable<Question> Get()
        {
            // Return a list of questions
            return _context.Questions.ToList();
        }

        // GET api/<QuestionController>/5
        [HttpGet("{id}")]
        public ActionResult<Question> Get(int id)
        {
            // Return an individual id that is connected to an question
            Question question = _context.Questions.Find(id);

            if (question != null)
            {
                return Ok(question);
            }
            else
            {
                return NotFound();
            }
        }

        // POST api/<QuestionController>
        [HttpPost]
        public IActionResult Post(Question question)
        {
            if (question != null)
            {
                // Create and save a question
                _context.Add(question);
                _context.SaveChanges();

                // Automatically redirect user to previous page
                return CreatedAtAction("Post", question);
            }
            return BadRequest();
        }

        // PUT api/<QuestionController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, Question question)
        {
            if (question != null && question.QuestionId == id)
            {
                // Edit and save an individual question
                _context.Questions.Update(question);
                _context.SaveChanges();

                // Automatically redirect user to previous page
                return Ok(question);
            }
            return BadRequest();
        }

        // DELETE api/<QuestionController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Question question = _context.Questions.Find(id);
            if (question != null)
            {
                // Delete and save changes to the database
                _context.Questions.Remove(question);
                _context.SaveChanges();

                // Automatically redirect user to previous page
                return Ok(question);
            }
            return NotFound();
        }

        #endregion

        #region Custom Endpoints

        // Custom Methods - Using .Include and specifying a property of the model tells entityframework to 
        // query and return that property with the overall query

        [Route("QuestionsWithAnswers")]
        public ActionResult<IEnumerable<Question>> QuestionsWithAnswers()
        {
            return _context.Questions.Include(c => c.Answers).ToList();
        }

        [Route("QuestionsForQuiz/{id}")]
        public ActionResult<IEnumerable<Question>> QuestionForQuiz(int id)
        {
            IEnumerable<Question> questionsForQuiz = _context.Questions.Include(c => c.Quiz).Where(c => c.QuizId == id);
            
            if (questionsForQuiz != null)
            {
                return Ok(questionsForQuiz);
            }
            else
            {
                return NotFound();
            }
        }
        #endregion

    }
}
