﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace QuickQuizApi.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Topics",
                columns: table => new
                {
                    TopicId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TopicName = table.Column<string>(nullable: true),
                    TopicDescription = table.Column<string>(nullable: true),
                    TopicColourOfPicFileName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Topics", x => x.TopicId);
                });

            migrationBuilder.CreateTable(
                name: "UserInfos",
                columns: table => new
                {
                    UserInfoId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserInfos", x => x.UserInfoId);
                });

            migrationBuilder.CreateTable(
                name: "Quizzes",
                columns: table => new
                {
                    QuizId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuizCreator = table.Column<string>(nullable: true),
                    QuizCreationDate = table.Column<DateTime>(nullable: false),
                    QuizName = table.Column<string>(nullable: true),
                    QuizDescription = table.Column<string>(nullable: true),
                    TopicId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Quizzes", x => x.QuizId);
                    table.ForeignKey(
                        name: "FK_Quizzes_Topics_TopicId",
                        column: x => x.TopicId,
                        principalTable: "Topics",
                        principalColumn: "TopicId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    QuestionId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionText = table.Column<string>(nullable: true),
                    QuestionNumber = table.Column<string>(nullable: true),
                    QuizId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.QuestionId);
                    table.ForeignKey(
                        name: "FK_Questions_Quizzes_QuizId",
                        column: x => x.QuizId,
                        principalTable: "Quizzes",
                        principalColumn: "QuizId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Answers",
                columns: table => new
                {
                    AnswerId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnswerText = table.Column<string>(nullable: true),
                    AnswerLetter = table.Column<string>(nullable: true),
                    IsCorrect = table.Column<bool>(nullable: false),
                    QuestionId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Answers", x => x.AnswerId);
                    table.ForeignKey(
                        name: "FK_Answers_Questions_QuestionId",
                        column: x => x.QuestionId,
                        principalTable: "Questions",
                        principalColumn: "QuestionId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Topics",
                columns: new[] { "TopicId", "TopicColourOfPicFileName", "TopicDescription", "TopicName" },
                values: new object[] { 1, null, "The state of being protected against the criminal or unauthorized use of electronic data, or the measures taken to achieve this.", "Cyber Security" });

            migrationBuilder.InsertData(
                table: "Topics",
                columns: new[] { "TopicId", "TopicColourOfPicFileName", "TopicDescription", "TopicName" },
                values: new object[] { 2, null, "The study or use of systems for storing, retrieving, and sending information.", "Information Technology" });

            migrationBuilder.InsertData(
                table: "UserInfos",
                columns: new[] { "UserInfoId", "Password", "UserName" },
                values: new object[] { 1, "1234", "Steve" });

            migrationBuilder.InsertData(
                table: "Quizzes",
                columns: new[] { "QuizId", "QuizCreationDate", "QuizCreator", "QuizDescription", "QuizName", "TopicId" },
                values: new object[] { 1, new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(844), "Stephen", "The security of ASP.Net", "ASP Net", 1 });

            migrationBuilder.InsertData(
                table: "Quizzes",
                columns: new[] { "QuizId", "QuizCreationDate", "QuizCreator", "QuizDescription", "QuizName", "TopicId" },
                values: new object[] { 2, new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(9832), "Shaun", "The security of HTTPS", "HTTPS", 1 });

            migrationBuilder.InsertData(
                table: "Quizzes",
                columns: new[] { "QuizId", "QuizCreationDate", "QuizCreator", "QuizDescription", "QuizName", "TopicId" },
                values: new object[] { 3, new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(9877), "Harry", "What is the definition of IT", "IT", 2 });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "QuestionId", "QuestionNumber", "QuestionText", "QuizId" },
                values: new object[,]
                {
                    { 1, "Question 1", "ICTPRG532", 1 },
                    { 2, "Question 2", "ICTPRG532", 1 },
                    { 3, "Question 3", "ICTPRG532", 2 },
                    { 4, "Question 4", "ICTPRG532", 3 }
                });

            migrationBuilder.InsertData(
                table: "Answers",
                columns: new[] { "AnswerId", "AnswerLetter", "AnswerText", "IsCorrect", "QuestionId" },
                values: new object[,]
                {
                    { 1, "A", "This is the text for the first answer", false, 1 },
                    { 2, "B", "This is the text for the second answer", false, 1 },
                    { 3, "C", "This is the text for the third answer", false, 1 },
                    { 4, "D", "This is the text for the fourth answer", false, 1 },
                    { 5, "E", "This is the text for the fifth answer", false, 1 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Answers_QuestionId",
                table: "Answers",
                column: "QuestionId");

            migrationBuilder.CreateIndex(
                name: "IX_Questions_QuizId",
                table: "Questions",
                column: "QuizId");

            migrationBuilder.CreateIndex(
                name: "IX_Quizzes_TopicId",
                table: "Quizzes",
                column: "TopicId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Answers");

            migrationBuilder.DropTable(
                name: "UserInfos");

            migrationBuilder.DropTable(
                name: "Questions");

            migrationBuilder.DropTable(
                name: "Quizzes");

            migrationBuilder.DropTable(
                name: "Topics");
        }
    }
}
