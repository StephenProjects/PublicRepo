﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace QuickQuizApi.Migrations
{
    public partial class final : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 1,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 27, 13, 33, 9, 154, DateTimeKind.Local).AddTicks(1384));

            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 2,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 27, 13, 33, 9, 155, DateTimeKind.Local).AddTicks(1408));

            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 3,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 27, 13, 33, 9, 155, DateTimeKind.Local).AddTicks(1459));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 1,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(844));

            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 2,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(9832));

            migrationBuilder.UpdateData(
                table: "Quizzes",
                keyColumn: "QuizId",
                keyValue: 3,
                column: "QuizCreationDate",
                value: new DateTime(2021, 5, 26, 12, 44, 20, 162, DateTimeKind.Local).AddTicks(9877));
        }
    }
}
